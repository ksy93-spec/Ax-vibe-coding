# rfx-volume 업데이트 2026.10.16.2

| 항목 | 값 |
| --- | --- |
| 적용 전 판 | 2026.10.16.1 |
| 적용 후 판 | 2026.10.16.2 |
| 커밋 | c21dfcd → f7f6757 |
| 만든 날 | 2026-10-16 |
| install.bat 다시 실행 | 필요 없음 |

## 적용 방법

1. 이 zip 을 아무 곳에나 풉니다. 바탕화면이나 다운로드 폴더도 됩니다.
2. 풀린 폴더의 `apply.bat` 을 실행합니다.
   `rfx-volume` 폴더는 이 폴더 안, 옆, 한두 단계 위에서 찾습니다. 못 찾으면 탐색기에서 `rfx-volume` 폴더를 검은 창으로 끌어다 놓고 Enter 를 누릅니다.
3. 판 번호가 맞으면 파일을 복사하고, 지워진 파일을 정리하고, `VERSION` 을 올립니다.
   판이 맞지 않으면 아무것도 바꾸지 않고 멈춥니다. `updates/README.md` 목록에서 빠진 업데이트부터 순서대로 적용하세요.
4. 킷 폴더의 `OFFLINE.md` 순서대로 확인합니다

적용이 끝나면 풀었던 폴더는 지워도 됩니다.

## 이번에 바뀐 내용

- f7f6757 kit(rfx-volume): 화면 개편, ECharts 차트와 Lucide 아이콘

## 파일 목록

### 추가 (36개)

- `web/vendor/echarts/LICENSE`
- `web/vendor/echarts/NOTICE`
- `web/vendor/echarts/echarts.min.js`
- `web/vendor/lucide/LICENSE`
- `web/vendor/lucide/arrow-left.svg`
- `web/vendor/lucide/arrow-right.svg`
- `web/vendor/lucide/building-2.svg`
- `web/vendor/lucide/calculator.svg`
- `web/vendor/lucide/car.svg`
- `web/vendor/lucide/chart-column.svg`
- `web/vendor/lucide/check.svg`
- `web/vendor/lucide/circle-check.svg`
- `web/vendor/lucide/clipboard-paste.svg`
- `web/vendor/lucide/copy.svg`
- `web/vendor/lucide/download.svg`
- `web/vendor/lucide/factory.svg`
- `web/vendor/lucide/file-spreadsheet.svg`
- `web/vendor/lucide/folder-open.svg`
- `web/vendor/lucide/gauge.svg`
- `web/vendor/lucide/globe-2.svg`
- `web/vendor/lucide/info.svg`
- `web/vendor/lucide/layers.svg`
- `web/vendor/lucide/moon.svg`
- `web/vendor/lucide/plus.svg`
- `web/vendor/lucide/printer.svg`
- `web/vendor/lucide/rotate-ccw.svg`
- `web/vendor/lucide/save.svg`
- `web/vendor/lucide/search.svg`
- `web/vendor/lucide/sliders-horizontal.svg`
- `web/vendor/lucide/sparkles.svg`
- `web/vendor/lucide/sun.svg`
- `web/vendor/lucide/table-2.svg`
- `web/vendor/lucide/trending-down.svg`
- `web/vendor/lucide/trending-up.svg`
- `web/vendor/lucide/triangle-alert.svg`
- `web/vendor/lucide/x.svg`

### 수정 (7개)

- `MANIFEST.md`
- `prompts/00-project-instructions.md`
- `prompts/20-screen-change.md`
- `web/css/app.css`
- `web/index.html`
- `web/js/app.js`
- `web/js/charts.js`

### 삭제 (0개)

- 없음

