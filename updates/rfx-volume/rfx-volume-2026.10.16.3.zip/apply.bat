@echo off
chcp 65001 >nul
setlocal
REM rfx-volume 업데이트 2026.10.16.3. zip 을 아무 곳에나 푼 뒤 이 파일을 실행합니다.
REM 킷 폴더를 끌어다 놓아 실행해도 됩니다: apply.bat <rfx-volume 폴더>
set "KIT="
if not "%~1"=="" call :try "%~1"
call :try "%~dp0rfx-volume"
call :try "%~dp0."
call :try "%~dp0.."
call :try "%~dp0..\rfx-volume"
call :try "%~dp0..\.."
call :try "%~dp0..\..\rfx-volume"
if defined KIT goto found
echo rfx-volume 폴더를 찾지 못했습니다.
echo 찾아본 곳: %~dp0rfx-volume, %~dp0..\rfx-volume, %~dp0..\..\rfx-volume
if exist "%~dp0..\rfx-volume\files\MANIFEST.md" echo 참고: %~dp0..\rfx-volume 는 킷이 아니라 업데이트 zip 을 푼 폴더로 보입니다. 처음 판 zip 의 apply.bat 을 먼저 실행하세요.
echo 탐색기에서 rfx-volume 폴더를 이 창으로 끌어다 놓고 Enter 를 누르세요.
set /p "ASK=폴더: "
if not defined ASK goto notkit
set "ASK=%ASK:"=%"
call :try "%ASK%"
if not defined KIT goto notkit
:found
if "%KIT:~-1%"=="\" set "KIT=%KIT:~0,-1%"
echo 킷 폴더: %KIT%
set "CUR="
if exist "%KIT%\VERSION" for /f "usebackq delims=" %%v in ("%KIT%\VERSION") do if not defined CUR set "CUR=%%v"
if not "%CUR%"=="2026.10.16.2" goto wrongver
if exist "%~dp0files" robocopy "%~dp0files" "%KIT%" /e /r:1 /w:1 /njh /njs /ndl /nfl /np >nul
if errorlevel 8 goto copyfail
>"%KIT%\VERSION" echo 2026.10.16.3
echo.
echo 적용했습니다. 판: 2026.10.16.3
echo 바뀐 파일 2개, 지운 파일 0개
echo 킷 폴더: %KIT%
echo 다음: 킷 폴더의 OFFLINE.md 순서대로 확인하세요.
pause
exit /b 0

:try
if defined KIT goto :eof
if not exist "%~1\MANIFEST.md" goto :eof
findstr /b /c:"# rfx-volume" "%~1\MANIFEST.md" >nul 2>nul && set "KIT=%~f1"
goto :eof

:notkit
echo rfx-volume 킷 폴더가 아닙니다. MANIFEST.md 가 있는 rfx-volume 폴더를 지정하세요.
pause
exit /b 1

:newexists
echo %NEW% 폴더가 이미 있지만 rfx-volume 킷 폴더가 아닙니다 (MANIFEST.md 가 없거나 다릅니다).
echo 그 폴더 이름을 바꾸거나 지운 뒤 다시 실행하세요. 아무것도 바꾸지 않았습니다.
pause
exit /b 1

:wrongver
echo 지금 판은 [%CUR%] 인데 이 업데이트는 2026.10.16.2 에 적용하는 것입니다.
echo 아무것도 바꾸지 않았습니다. updates\README.md 목록에서 빠진 업데이트부터 순서대로 적용하세요.
pause
exit /b 1

:copyfail
echo 파일 복사에 실패했습니다. 킷 폴더의 파일이 다른 프로그램에서 열려 있지 않은지 확인하세요.
pause
exit /b 1
