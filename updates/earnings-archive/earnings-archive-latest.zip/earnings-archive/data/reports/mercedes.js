// 회사 하나의 분기 실적과 컨퍼런스콜 요약. 금액은 발표 통화 백만 단위, 판매 대수는 천 대.
// 자동 생성 파일입니다. 손으로 고칠 때는 JSON 문법(큰따옴표, 마지막 쉼표 없음)을 지키세요.
(window.EA_FILES = window.EA_FILES || []).push({
 "kind": "report",
 "data": {
  "company": "mercedes",
  "rev": 2,
  "quarters": [
   {
    "period": "2026Q3",
    "fiscalLabel": "Q3 2026",
    "reportDate": "",
    "currency": "EUR",
    "values": {
     "revenue": 30700,
     "operatingIncome": 1773,
     "deliveries": 491.653,
     "totalEquity": 94279,
     "totalLiabilities": 162138
    },
    "raw": {
     "revenue": "revenue of 30.7 billion euros",
     "operatingIncome": "EBIT 1,773"
    },
    "source": "https://group.mercedes-benz.com/investors/reports-news/interim-reports/q3-2026/ https://group.mercedes-benz.com/documents/investors/reports/interim-reports/q3/mercedes-benz-interim-report-q3-2026.pdf https://media.mercedes-benz.com/en/article/300f16c7-24b3-4f6c-a00b-a037d8049c4f",
    "status": "검증 필요",
    "note": "웹 검색으로 회사 문서 인용을 확인한 값. 원문 대조 전. revenue rounded (30.7bn); units = Cars 407,232 + Vans 84,421; published 2026-10-28",
    "call": null,
    "origin": "outside",
    "updatedAt": "2026-11-02 00:00:00"
   },
   {
    "period": "2026Q2",
    "fiscalLabel": "Q2 2026",
    "reportDate": "",
    "currency": "EUR",
    "values": {
     "revenue": 32061,
     "operatingIncome": 1547,
     "deliveries": 511.84
    },
    "raw": {
     "revenue": "Q2 2026 revenue 32,061 vs 33,153; H1 63,663",
     "operatingIncome": "Q2 EBIT 1,547 vs 1,273; H1 3,451",
     "deliveries": "Cars 417,765 + Vans 94,075"
    },
    "source": "https://group.mercedes-benz.com/documents/investors/reports/interim-reports/q2/mercedes-benz-interim-report-q2-2026.pdf https://group.mercedes-benz.com/documents/investors/reports/interim-reports/q2/mercedes-benz-interim-report-q2-2026.pdf",
    "status": "검증 필요",
    "note": "웹 검색으로 공식 문서 인용을 확인한 값. 원문 PDF 대조 전. 분기 말 자본총계, 자산총계를 확인하지 못해 부채비율 비움 Balance sheet at 30 Jun 2026 NOT found. Revenue/EBIT Q2 reported directly. 63,663-32,061=31,602 matches Q1.",
    "call": null,
    "origin": "outside",
    "updatedAt": "2026-10-26 02:47:05"
   },
   {
    "period": "2026Q1",
    "fiscalLabel": "Q1 2026",
    "reportDate": "",
    "currency": "EUR",
    "values": {
     "revenue": 31602,
     "operatingIncome": 1904,
     "totalEquity": 95228,
     "totalLiabilities": 163390
    },
    "raw": {
     "revenue": "Revenue | 31,602 | 33,224 | -5",
     "operatingIncome": "EBIT | 1,904 | 2,289 | -17",
     "totalEquity": "Total equity 95,228",
     "totalLiabilities": "Total equity and liabilities 258,618"
    },
    "source": "https://group.mercedes-benz.com/documents/investors/reports/interim-reports/q1/mercedes-benz-interim-report-q1-2026.pdf https://group.mercedes-benz.com/documents/investors/reports/interim-reports/q1/mercedes-benz-interim-report-q1-2026.pdf",
    "status": "검증 필요",
    "note": "웹 검색으로 공식 문서 인용을 확인한 값. 원문 PDF 대조 전. 부채총계 = 자산총계 258618 - 자본총계 95228 Quotes are from WebSearch-extracted report text (table rows/sentences), not opened PDFs. WARNING: 95,228/258,618=36.8% vs reported 35.5%.",
    "call": null,
    "origin": "outside",
    "updatedAt": "2026-10-26 02:47:05"
   },
   {
    "period": "2025Q4",
    "fiscalLabel": "Q4 2025",
    "reportDate": "",
    "currency": "EUR",
    "values": {
     "revenue": 33690,
     "operatingIncome": 1508,
     "totalEquity": 94240,
     "totalLiabilities": 161226,
     "deliveries": 558.4
    },
    "raw": {
     "revenue": "Revenue ... 33,690 -12.4",
     "operatingIncome": "Q4 2025 EBIT 1,508 vs 3,182",
     "totalEquity": "Q1 2026 report: 94,240 at 31 Dec 2025",
     "totalLiabilities": "255,466 at 31 Dec 2025"
    },
    "source": "https://group.mercedes-benz.com/dokumente/investoren/berichte/geschaeftsberichte/mercedes-benz/mercedes-benz-factsheet-q4-2025.pdf https://group.mercedes-benz.com/documents/investors/reports/interim-reports/q1/mercedes-benz-interim-report-q1-2026.pdf https://group.mercedes-benz.com/company/news/sales-2025.html https://group.mercedes-benz.com/documents/investors/reports/interim-reports/q1/mercedes-benz-interim-report-q1-2026.pdf",
    "status": "검증 필요",
    "note": "웹 검색으로 공식 문서 인용을 확인한 값. 원문 PDF 대조 전. 부채총계 = 자산총계 255466 - 자본총계 94240 Quotes are from WebSearch-extracted report text (table rows/sentences), not opened PDFs. Balance sheet values are 31 Dec 2025 comparatives in Q1 2026 report. Column order of fact sheet inferred. Equity ratio for 31 Dec 2025 not found.",
    "call": null,
    "origin": "outside",
    "updatedAt": "2026-10-26 02:47:05"
   },
   {
    "period": "2025Q3",
    "fiscalLabel": "Q3 2025",
    "reportDate": "",
    "currency": "EUR",
    "values": {
     "revenue": 32147,
     "operatingIncome": 750,
     "deliveries": 525.296,
     "totalEquity": 92614,
     "totalLiabilities": 163228
    },
    "raw": {
     "revenue": "Fact sheet Q3 2025 revenue 32,147",
     "operatingIncome": "EBIT 750"
    },
    "source": "https://group.mercedes-benz.com/documents/investors/reports/interim-reports/q3/mercedes-benz-interim-report-q3-2025.pdf https://group.mercedes-benz.com/documents/investors/reports/interim-reports/q3/mercedes-benz-interim-report-q3-2025.pdf",
    "status": "검증 필요",
    "note": "웹 검색으로 공식 문서 인용을 확인한 값. 원문 PDF 대조 전. 분기 말 자본총계, 자산총계를 확인하지 못해 부채비율 비움 (회사 표기 자기자본비율 34.6%, 정의가 달라 쓰지 않음) Quotes are from WebSearch-extracted report text (table rows/sentences), not opened PDFs. Total equity ~EUR 92.6bn ('equity decreased from 93.6 to 92.6bn') but exact figure 92,614 not confirmed to label; total assets not found.",
    "call": null,
    "origin": "outside",
    "updatedAt": "2026-10-26 02:47:05"
   },
   {
    "period": "2025Q2",
    "fiscalLabel": "Q2 2025",
    "reportDate": "",
    "currency": "EUR",
    "values": {
     "revenue": 33153,
     "operatingIncome": 1273,
     "totalEquity": 91719,
     "totalLiabilities": 164908,
     "deliveries": 547.1
    },
    "raw": {
     "revenue": "Q2 2026 report comparative 33,153; fact sheet row 33,224 | 33,153 | 32,147",
     "operatingIncome": "Q2 2026 report comparative 1,273",
     "totalEquity": "Equity 91,719 ... Total equity and liabilities 256,627"
    },
    "source": "https://group.mercedes-benz.com/documents/investors/reports/interim-reports/q2/mercedes-benz-interim-report-q2-2025.pdf https://group.mercedes-benz.com/documents/investors/reports/interim-reports/q2/mercedes-benz-interim-report-q2-2026.pdf https://group.mercedes-benz.com/documents/investors/reports/interim-reports/q2/mercedes-benz-interim-report-q2-2025.pdf https://media.mbusa.com/releases/mercedes-benz-sold-547100-cars-and-vans-in-q2",
    "status": "검증 필요",
    "note": "웹 검색으로 공식 문서 인용을 확인한 값. 원문 PDF 대조 전. 부채총계 = 자산총계 256627 - 자본총계 91719 Quotes are from WebSearch-extracted report text (table rows/sentences), not opened PDFs. WARNING: 91,719/256,627=35.7% vs reported ratio 34.1%; unresolved definitional gap. Revenue/EBIT Q2 2025 taken via Q2 2026 comparatives/Q4 2025 fact sheet row, not the Q2 2025 report directly.",
    "call": null,
    "origin": "outside",
    "updatedAt": "2026-10-26 02:47:05"
   },
   {
    "period": "2025Q1",
    "fiscalLabel": "Q1 2025",
    "reportDate": "",
    "currency": "EUR",
    "values": {
     "revenue": 33224,
     "operatingIncome": 2289,
     "deliveries": 529.2
    },
    "raw": {
     "revenue": "Revenue* | 33,224 | 35,873 | -7.4%",
     "operatingIncome": "Earnings before interest and taxes (EBIT)* | 2,289 | 3,863 | -40.7%",
     "deliveries": "529,200 cars and vans (Cars 446,300 + Vans 82,900)"
    },
    "source": "https://group.mercedes-benz.com/dokumente/investoren/berichte/zwischenberichte/q1/mercedes-benz-fact-sheet-q1-2025.pdf https://www.automotiveworld.com/news-releases/mercedes-benz-sold-529200-cars-and-vans-in-q1-2025/",
    "status": "검증 필요",
    "note": "웹 검색으로 공식 문서 인용을 확인한 값. 원문 PDF 대조 전. 분기 말 자본총계, 자산총계를 확인하지 못해 부채비율 비움 Balance sheet items at 31 Mar 2025 NOT found (Q1 2025 interim report not retrievable).",
    "call": null,
    "origin": "outside",
    "updatedAt": "2026-10-26 02:47:05"
   },
   {
    "period": "2024Q4",
    "fiscalLabel": "Q4 2024",
    "reportDate": "",
    "currency": "EUR",
    "values": {
     "revenue": 38450,
     "operatingIncome": 3182,
     "totalEquity": 93630,
     "totalLiabilities": 171380
    },
    "raw": {
     "revenue": "Revenue 38,450 (-3.8%)",
     "operatingIncome": "Q4 Group EBIT EUR 3,182m vs 4,326m",
     "totalEquity": "Q2 2025 report prior-year-end equity 93,630",
     "totalLiabilities": "Q3 2025 report comparative 265,010"
    },
    "source": "https://group.mercedes-benz.com/dokumente/investoren/berichte/geschaeftsberichte/mercedes-benz/mercedes-benz-factsheet-q4-2024.pdf https://group.mercedes-benz.com/documents/investors/reports/interim-reports/q2/mercedes-benz-interim-report-q2-2025.pdf https://group.mercedes-benz.com/documents/investors/reports/interim-reports/q3/mercedes-benz-interim-report-q3-2025.pdf https://group.mercedes-benz.com/documents/investors/reports/interim-reports/q2/mercedes-benz-interim-report-q2-2025.pdf",
    "status": "검증 필요",
    "note": "웹 검색으로 공식 문서 인용을 확인한 값. 원문 PDF 대조 전. 부채총계 = 자산총계 265010 - 자본총계 93630 Quotes are from WebSearch-extracted report text (table rows/sentences), not opened PDFs. Revenue/EBIT are Q4 column of fact sheet. Balance sheet values are 31 Dec 2024 comparatives in 2025 interim reports, not the annual report itself. WARNING: 93,630/265,010=35.3% but reported ratio is 33.8%; ratio definition appears to differ from equity/total from 2025 reports (see Q2 2025, Q1 2026). Use equity/assets for consistency or flag.",
    "call": null,
    "origin": "outside",
    "updatedAt": "2026-10-26 02:47:05"
   },
   {
    "period": "2024Q3",
    "fiscalLabel": "Q3 2024",
    "reportDate": "",
    "currency": "EUR",
    "values": {
     "revenue": 34528,
     "operatingIncome": 2517,
     "totalEquity": 90808,
     "totalLiabilities": 171209
    },
    "raw": {
     "revenue": "Q3 2024 revenue EUR 34,528m vs 37,001m",
     "operatingIncome": "Q3 2024 EBIT EUR 2,517m vs 4,842m",
     "totalEquity": "Total equity 90,808",
     "totalLiabilities": "Total assets 262,017 263,022"
    },
    "source": "https://group.mercedes-benz.com/documents/investors/reports/interim-reports/q3/mercedes-benz-interim-report-q3-2024.pdf",
    "status": "검증 필요",
    "note": "웹 검색으로 공식 문서 인용을 확인한 값. 원문 PDF 대조 전. 부채총계 = 자산총계 262017 - 자본총계 90808 Quotes are from WebSearch-extracted report text (table rows/sentences), not opened PDFs. 90,808/262,017=34.7% consistent.",
    "call": null,
    "origin": "outside",
    "updatedAt": "2026-10-26 02:47:05"
   },
   {
    "period": "2024Q2",
    "fiscalLabel": "Q2 2024",
    "reportDate": "",
    "currency": "EUR",
    "values": {
     "revenue": 36743,
     "operatingIncome": 4037,
     "totalEquity": 91138,
     "totalLiabilities": 172035
    },
    "raw": {
     "revenue": "given by caller (Q2 2024 factsheet)",
     "operatingIncome": "given by caller (Q2 2024 factsheet)",
     "totalEquity": "Total equity 91,138 (31 Dec 2023: 92,816)",
     "totalLiabilities": "Balance sheet total 263,173"
    },
    "source": "https://group.mercedes-benz.com/documents/investors/reports/interim-reports/q2/mercedes-benz-zwischenbericht-q2-2024-en.pdf",
    "status": "검증 필요",
    "note": "웹 검색으로 공식 문서 인용을 확인한 값. 원문 PDF 대조 전. 부채총계 = 자산총계 263173 - 자본총계 91138 Quotes are from WebSearch-extracted report text (table rows/sentences), not opened PDFs. Total assets labelled 'Balance sheet total'.",
    "call": null,
    "origin": "outside",
    "updatedAt": "2026-10-26 02:47:05"
   },
   {
    "period": "2024Q1",
    "fiscalLabel": "Q1 2024",
    "reportDate": "",
    "currency": "EUR",
    "values": {
     "revenue": 35873,
     "operatingIncome": 3863,
     "totalEquity": 96828,
     "totalLiabilities": 170321
    },
    "raw": {
     "revenue": "Revenue 35,873 37,516 -4",
     "operatingIncome": "Earnings before Interest and Taxes (EBIT)* 3,863 5,504 -29.8%",
     "totalEquity": "Group total equity of 96,828 at 31 March 2024",
     "totalLiabilities": "Total equity and liabilities | 267,149 | 263,022"
    },
    "source": "https://group.mercedes-benz.com/documents/investors/reports/interim-reports/q1/mercedes-benz-interim-report-q1-2024.pdf",
    "status": "검증 필요",
    "note": "웹 검색으로 공식 문서 인용을 확인한 값. 원문 PDF 대조 전. 부채총계 = 자산총계 267149 - 자본총계 96828 Quotes are from WebSearch-extracted report text (table rows/sentences), not opened PDFs. Revenue/EBIT also via businesswire 20240429275433. Equity 96,828/267,149=36.2% consistent.",
    "call": null,
    "origin": "outside",
    "updatedAt": "2026-10-26 02:47:05"
   },
   {
    "period": "2023Q4",
    "fiscalLabel": "Q4 2023",
    "reportDate": "",
    "currency": "EUR",
    "values": {
     "revenue": 40261,
     "operatingIncome": 4326,
     "totalEquity": 92816,
     "totalLiabilities": 170206
    },
    "raw": {
     "revenue": "Q4 2023 revenue 40,261",
     "operatingIncome": "Q4 EBIT 4,326",
     "totalEquity": "Total equity 96,828 | 92,816; Total equity and liabilities 267,149 | 263,022 (Q1 2024 report, Mar 2024 | Dec 2023 column order inferred)"
    },
    "source": "https://group.Mercedes-benz.com/dokumente/investoren/berichte/geschaeftsberichte/mercedes-benz/mercedes-benz-factsheet-q4-2023-final.pdf https://group.mercedes-benz.com/documents/investors/reports/interim-reports/q1/mercedes-benz-interim-report-q1-2024.pdf",
    "status": "검증 필요",
    "note": "웹 검색으로 공식 문서 인용을 확인한 값. 원문 PDF 대조 전. 부채총계 = 자산총계 263022 - 자본총계 92816 Balance sheet from Q1 2024 comparative column; column order inferred from text extraction, verify. FY2023 revenue 153,218, EBIT 19,660.",
    "call": null,
    "origin": "outside",
    "updatedAt": "2026-10-26 02:47:05"
   },
   {
    "period": "2023Q3",
    "fiscalLabel": "Q3 2023",
    "reportDate": "",
    "currency": "EUR",
    "values": {
     "revenue": 37200,
     "operatingIncome": 4842
    },
    "raw": {
     "revenue": "Revenue 37,200",
     "operatingIncome": "EBIT 4,842"
    },
    "source": "https://group.mercedes-benz.com/documents/investors/reports/interim-reports/q3/mercedes-benz-interim-report-q3-2023.pdf",
    "status": "검증 필요",
    "note": "웹 검색으로 공식 문서 인용을 확인한 값. 원문 PDF 대조 전. 분기 말 자본총계, 자산총계를 확인하지 못해 부채비율 비움 Balance sheet total at 30 Sep 2023 slightly above 31 Dec 2022 per report; figures not confirmed. Q3 2024 report restates 2023 comparatives.",
    "call": null,
    "origin": "outside",
    "updatedAt": "2026-10-26 02:47:05"
   },
   {
    "period": "2023Q2",
    "fiscalLabel": "Q2 2023",
    "reportDate": "",
    "currency": "EUR",
    "values": {
     "revenue": 38241,
     "operatingIncome": 4988
    },
    "raw": {
     "revenue": "Revenue 38,241 36,440 +5",
     "operatingIncome": "EBIT 4,988 4,622 +8"
    },
    "source": "https://group.mercedes-benz.com/documents/investors/reports/interim-reports/q2/mercedes-benz-interim-report-q2-2023.pdf",
    "status": "검증 필요",
    "note": "웹 검색으로 공식 문서 인용을 확인한 값. 원문 PDF 대조 전. 분기 말 자본총계, 자산총계를 확인하지 못해 부채비율 비움 Equity line seen as 88,675 in garbled extract but unconfirmed, so left null; balance sheet total slightly below 31 Dec 2022 per report.",
    "call": null,
    "origin": "outside",
    "updatedAt": "2026-10-26 02:47:05"
   },
   {
    "period": "2023Q1",
    "fiscalLabel": "Q1 2023",
    "reportDate": "",
    "currency": "EUR",
    "values": {
     "revenue": 37516,
     "operatingIncome": 5504,
     "totalEquity": 90911,
     "totalLiabilities": 172333
    },
    "raw": {
     "revenue": "Q1 2023 revenue 37,516 (Q4 2023 factsheet / Q1 2024 comparative)",
     "operatingIncome": "EBIT 5,504 5,229 +5",
     "totalEquity": "Equity 90,911; total assets 263,244 (31 March 2023)"
    },
    "source": "https://group.mercedes-benz.com/documents/investors/reports/interim-reports/q1/mercedes-benz-interim-report-q1-2023.pdf https://group.Mercedes-benz.com/dokumente/investoren/berichte/geschaeftsberichte/mercedes-benz/mercedes-benz-factsheet-q4-2023-final.pdf",
    "status": "검증 필요",
    "note": "웹 검색으로 공식 문서 인용을 확인한 값. 원문 PDF 대조 전. 부채총계 = 자산총계 263244 - 자본총계 90911 Revenue 37,516 from later comparatives; Q1 2023 report press text says 37.5bn - exact in own report not directly seen.",
    "call": null,
    "origin": "outside",
    "updatedAt": "2026-10-26 02:47:05"
   },
   {
    "period": "2022Q4",
    "fiscalLabel": "Q4 2022",
    "reportDate": "",
    "currency": "EUR",
    "values": {
     "revenue": 41003,
     "operatingIncome": 5411,
     "totalEquity": 86540,
     "totalLiabilities": 173475
    },
    "raw": {
     "revenue": "Revenue** | 41,003 | 35,240 | +16%",
     "operatingIncome": "EBIT** | 5,411 | 4,115 | +31%",
     "totalEquity": "Equity 90,911 versus 86,540; total equity and liabilities 260,015 (31 Dec 2022 column of Q1 2023 report)"
    },
    "source": "https://group.Mercedes-benz.com/dokumente/investoren/berichte/geschaeftsberichte/mercedes-benz/mercedes-benz-factsheet-q4-2022-final.pdf https://group.mercedes-benz.com/documents/investors/reports/interim-reports/q1/mercedes-benz-interim-report-q1-2023.pdf",
    "status": "검증 필요",
    "note": "웹 검색으로 공식 문서 인용을 확인한 값. 원문 PDF 대조 전. 부채총계 = 자산총계 260015 - 자본총계 86540 Q4 from factsheet quarterly table. Balance sheet taken from Q1 2023 report comparative column (31 Dec 2022). FY2022 revenue 150,017, EBIT 20,458.",
    "call": null,
    "origin": "outside",
    "updatedAt": "2026-10-26 02:47:05"
   },
   {
    "period": "2022Q3",
    "fiscalLabel": "Q3 2022",
    "reportDate": "",
    "currency": "EUR",
    "values": {
     "revenue": 37716,
     "operatingIncome": 5196
    },
    "raw": {
     "revenue": "Group revenue for Q3 2022 was 37,716",
     "operatingIncome": "EBIT 5,196"
    },
    "source": "https://group.mercedes-benz.com/documents/investors/reports/interim-reports/q3/mercedes-benz-ir-interim-report-q3-2022.pdf",
    "status": "검증 필요",
    "note": "웹 검색으로 공식 문서 인용을 확인한 값. 원문 PDF 대조 전. 분기 말 자본총계, 자산총계를 확인하지 못해 부채비율 비움 Report says balance sheet total at 30 Sep 2022 slightly above 31 Dec 2021; figures not confirmed.",
    "call": null,
    "origin": "outside",
    "updatedAt": "2026-10-26 02:47:05"
   },
   {
    "period": "2022Q2",
    "fiscalLabel": "Q2 2022",
    "reportDate": "",
    "currency": "EUR",
    "values": {
     "revenue": 36440,
     "operatingIncome": 4622
    },
    "raw": {
     "revenue": "Revenue 36,440 (Q2 2023 report comparatives)",
     "operatingIncome": "EBIT 4,622"
    },
    "source": "https://group.mercedes-benz.com/documents/investors/reports/interim-reports/q2/mercedes-benz-ir-interim-report-q2-2022.pdf https://group.mercedes-benz.com/documents/investors/reports/interim-reports/q2/mercedes-benz-interim-report-q2-2023.pdf",
    "status": "검증 필요",
    "note": "웹 검색으로 공식 문서 인용을 확인한 값. 원문 PDF 대조 전. 분기 말 자본총계, 자산총계를 확인하지 못해 부채비율 비움 Balance sheet not confirmed.",
    "call": null,
    "origin": "outside",
    "updatedAt": "2026-10-26 02:47:05"
   },
   {
    "period": "2022Q1",
    "fiscalLabel": "Q1 2022",
    "reportDate": "",
    "currency": "EUR",
    "values": {
     "revenue": 34858,
     "operatingIncome": 5229
    },
    "raw": {
     "revenue": "H1 2022 revenue 71,298 less Q2 36,440 (Q2 2023 report comparatives); Q4 2022 factsheet row 35,240 34,858 36,440 37,716 41,003",
     "operatingIncome": "EBIT 5,229 4,701"
    },
    "source": "https://group.mercedes-benz.com/documents/investors/reports/interim-reports/q1/mercedes-benz-ir-interim-report-q1-2022.pdf https://group.Mercedes-benz.com/dokumente/investoren/berichte/geschaeftsberichte/mercedes-benz/mercedes-benz-factsheet-q4-2022-final.pdf",
    "status": "검증 필요",
    "note": "웹 검색으로 공식 문서 인용을 확인한 값. 원문 PDF 대조 전. 분기 말 자본총계, 자산총계를 확인하지 못해 부채비율 비움 Revenue 34,858 from factsheet quarterly row (press says 34.9bn). Balance sheet 31 Mar 2022 not confirmed from official source (third-party Fintel equity 78,422, unverified).",
    "call": null,
    "origin": "outside",
    "updatedAt": "2026-10-26 02:47:05"
   },
   {
    "period": "2021Q4",
    "fiscalLabel": "Q4 2021",
    "reportDate": "",
    "currency": "EUR",
    "values": {
     "revenue": 43389,
     "operatingIncome": 14557
    },
    "raw": {
     "revenue": "Q4 revenue 43,389 (-7%) per Q4 2021 results table",
     "operatingIncome": "Q4 2021 group EBIT 14,557 incl. one-time EUR9.2bn deconsolidation gain"
    },
    "source": "https://group.mercedes-benz.com/results-2021 https://group.Mercedes-benz.com/dokumente/investoren/berichte/geschaeftsberichte/mercedes-benz/mercedes-benz-ir-factsheet-q4-2021.pdf",
    "status": "검증 필요",
    "note": "웹 검색으로 공식 문서 인용을 확인한 값. 원문 PDF 대조 전. 분기 말 자본총계, 자산총계를 확인하지 못해 부채비율 비움 Continuing-operations restated (ex Daimler Truck) per later reports: Q4 revenue 35,240, EBIT 4,115 (Q4 2022 factsheet comparative); FY2021 continuing revenue 133,893, EBIT 16.0bn. Original Q4 EBIT includes discontinued ops and the 9.2bn spin-off gain. Balance sheet at 31 Dec 2021 not confirmed from official source (third-party Fintel shows equity 73,167, unverified).",
    "call": null,
    "origin": "outside",
    "updatedAt": "2026-10-26 02:47:05"
   },
   {
    "period": "2021Q3",
    "fiscalLabel": "Q3 2021",
    "reportDate": "",
    "currency": "EUR",
    "values": {
     "revenue": 40083,
     "operatingIncome": 3579
    },
    "raw": {
     "revenue": "Daimler Group revenue 40,083 (Q3 2020 40,281) per Q3 2021 factsheet",
     "operatingIncome": "Group EBIT rose to EUR3,579 million (EUR3,070 million)"
    },
    "source": "https://group.mercedes-benz.com/documents/investors/reports/interim-reports/q3/daimler-ir-interim-report-q3-2021.pdf https://group.Mercedes-benz.com/dokumente/investoren/berichte/zwischenberichte/q3/daimler-ir-factsheet-q3-2021.pdf",
    "status": "검증 필요",
    "note": "웹 검색으로 공식 문서 인용을 확인한 값. 원문 PDF 대조 전. 분기 말 자본총계, 자산총계를 확인하지 못해 부채비율 비움 Continuing-operations restated (ex Daimler Truck) per later reports: revenue 31,647, EBIT 2,838 (Q3 2022 release comparative). Original includes Daimler Trucks (held for distribution in balance sheet). Equity at 30 Sep 2021 not confirmed.",
    "call": null,
    "origin": "outside",
    "updatedAt": "2026-10-26 02:47:05"
   },
   {
    "period": "2021Q2",
    "fiscalLabel": "Q2 2021",
    "reportDate": "",
    "currency": "EUR",
    "values": {
     "revenue": 43482,
     "operatingIncome": 5185,
     "totalEquity": 72141,
     "totalLiabilities": 220591
    },
    "raw": {
     "revenue": "Revenue grew by 44% to EUR43.5 billion; factsheet table 43,482",
     "operatingIncome": "EBIT of EUR5,185 million (Q2 2020: minus EUR1,682 million)",
     "totalEquity": "total equity of 72,141 and total equity and liabilities of 292,732 (Consolidated Statement of Financial Position C.05)"
    },
    "source": "https://group.mercedes-benz.com/documents/investors/reports/interim-reports/q2/daimler-ir-interimreport-q2-2021.pdf https://group.mercedes-benz.com/investors/reports-news/financial-news/20210714-daimler-q2-2021.html https://group.Mercedes-benz.com/dokumente/investoren/berichte/zwischenberichte/q2/daimler-ir-factsheet-q2-2021.pdf",
    "status": "검증 필요",
    "note": "웹 검색으로 공식 문서 인용을 확인한 값. 원문 PDF 대조 전. 부채총계 = 자산총계 292732 - 자본총계 72141 Continuing-operations restated (ex Daimler Truck) per later reports: revenue 34.1bn (Q2 2022 report comparative). Original includes Daimler Trucks.",
    "call": null,
    "origin": "outside",
    "updatedAt": "2026-10-26 02:47:05"
   },
   {
    "period": "2021Q1",
    "fiscalLabel": "Q1 2021",
    "reportDate": "",
    "currency": "EUR",
    "values": {
     "revenue": 41017,
     "operatingIncome": 5748,
     "totalEquity": 67993,
     "totalLiabilities": 227345
    },
    "raw": {
     "revenue": "Revenue 41,017 37,223 +10%",
     "operatingIncome": "EBIT 5,748 617 +832%",
     "totalEquity": "Equity of 67,993 and total equity and liabilities of 295,338 (search summary of Q1 2021 report, condensed balance sheet)"
    },
    "source": "https://group.mercedes-benz.com/documents/investors/reports/interim-reports/q1/daimler-ir-interimreport-q1-2021.pdf https://group.mercedes-benz.com/investors/reports-news/financial-news/20210416-daimler-q1-2021.html",
    "status": "검증 필요",
    "note": "웹 검색으로 공식 문서 인용을 확인한 값. 원문 PDF 대조 전. 부채총계 = 자산총계 295338 - 자본총계 67993 Continuing-operations restated (ex Daimler Truck) per later reports: revenue 32.9bn (Q1 2022 report comparative), EBIT 4,701. Original includes Daimler Trucks. Equity line labelled 'Equity' in report; totalAssets = total equity and liabilities.",
    "call": null,
    "origin": "outside",
    "updatedAt": "2026-10-26 02:47:05"
   },
   {
    "period": "2020Q4",
    "fiscalLabel": "Q4 2020",
    "reportDate": "",
    "currency": "EUR",
    "values": {
     "revenue": 46621,
     "operatingIncome": 4598,
     "totalEquity": 62248,
     "totalLiabilities": 223489
    },
    "raw": {
     "revenue": "Q4 revenue EUR 46,621 million vs 47,127 (FY2020 results table)",
     "operatingIncome": "Q4 EBIT 4,598 vs 383",
     "totalEquity": "Total equity 62,248",
     "totalLiabilities": "Total equity and liabilities 285,737"
    },
    "source": "https://media.mercedes-benz.it/download/984420/20210218-daimler-ag-table-results-fy-2020.pdf https://annualreport.daimler.com/2020/combined-management-report-with-non-financial-statement/profitability-liquidity-and-capital-resources-financial-position/financial-position/",
    "status": "검증 필요",
    "note": "웹 검색으로 공식 문서 인용을 확인한 값. 원문 PDF 대조 전. 부채총계 = 자산총계 285737 - 자본총계 62248 Figures come from WebSearch result summaries of the PDFs (PDFs not opened directly); quotes are as returned by the search. Later restated for Daimler Truck spin-off (2021); not used.",
    "call": null,
    "origin": "outside",
    "updatedAt": "2026-10-26 02:47:05"
   },
   {
    "period": "2020Q3",
    "fiscalLabel": "Q3 2020",
    "reportDate": "",
    "currency": "EUR",
    "values": {
     "revenue": 40281,
     "operatingIncome": 3070,
     "totalEquity": 58623,
     "totalLiabilities": 232030
    },
    "raw": {
     "revenue": "Revenue 40,281 (Q3 2020 factsheet); release: 'slipped by 7% to EUR 40.3 billion'",
     "operatingIncome": "EBIT increased by 14% to EUR 3,070 million (Q3 2019: EUR 2,690 million)",
     "totalEquity": "Total equity 58,623",
     "totalLiabilities": "Total equity and liabilities 290,653"
    },
    "source": "https://group.mercedes-benz.com/documents/investors/reports/interim-reports/q3/daimler-ir-interimreport-q3-2020.pdf https://group.Mercedes-benz.com/dokumente/investoren/berichte/zwischenberichte/q3/daimler-ir-factsheet-q3-2020.pdf",
    "status": "검증 필요",
    "note": "웹 검색으로 공식 문서 인용을 확인한 값. 원문 PDF 대조 전. 부채총계 = 자산총계 290653 - 자본총계 58623 Figures come from WebSearch result summaries of the PDFs (PDFs not opened directly); quotes are as returned by the search. 9M check: 37,223+30,184+40,281=107,688 matches YTD.",
    "call": null,
    "origin": "outside",
    "updatedAt": "2026-10-26 02:47:05"
   },
   {
    "period": "2020Q2",
    "fiscalLabel": "Q2 2020",
    "reportDate": "",
    "currency": "EUR",
    "values": {
     "revenue": 30184,
     "operatingIncome": -1682,
     "totalEquity": 58857,
     "totalLiabilities": 235908
    },
    "raw": {
     "revenue": "Revenue fell to EUR 30.2 billion (Q2 2019: EUR 42.7 billion); factsheet row 30,184",
     "operatingIncome": "EBIT was minus EUR 1,682 million (Q2 2019: minus EUR 1,558 million)",
     "totalEquity": "Equity 58,857 | 62,841",
     "totalLiabilities": "Total equity and liabilities 294,765 | 302,438"
    },
    "source": "https://group.mercedes-benz.com/documents/investors/reports/interim-reports/q2/daimler-ir-interimreport-q2-2020.pdf https://group.Mercedes-benz.com/dokumente/investoren/berichte/zwischenberichte/q3/daimler-ir-factsheet-q3-2020.pdf",
    "status": "검증 필요",
    "note": "웹 검색으로 공식 문서 인용을 확인한 값. 원문 PDF 대조 전. 부채총계 = 자산총계 294765 - 자본총계 58857 Figures come from WebSearch result summaries of the PDFs (PDFs not opened directly); quotes are as returned by the search. Equity ratio for 30 Jun 2020 not confirmed. One search summary cited an unrelated 'EBIT 263' (ignore, likely different item).",
    "call": null,
    "origin": "outside",
    "updatedAt": "2026-10-26 02:47:05"
   },
   {
    "period": "2020Q1",
    "fiscalLabel": "Q1 2020",
    "reportDate": "",
    "currency": "EUR",
    "values": {
     "revenue": 37223,
     "operatingIncome": 617,
     "totalEquity": 63163,
     "totalLiabilities": 234500
    },
    "raw": {
     "revenue": "Revenue 37,223 (Q3 2020 factsheet); release: 'Revenue slipped slightly by 6% to EUR 37.2 billion'",
     "operatingIncome": "First quarter EBIT was EUR 617 million (Q1 2019: EUR 2,798 million)",
     "totalEquity": "Equity 63,163 | 62,841",
     "totalLiabilities": "Total equity and liabilities 297,663 | 302,438"
    },
    "source": "https://group.mercedes-benz.com/documents/investors/reports/interim-reports/q1/daimler-ir-interimreport-q1-2020.pdf https://group.Mercedes-benz.com/dokumente/investoren/berichte/zwischenberichte/q3/daimler-ir-factsheet-q3-2020.pdf",
    "status": "검증 필요",
    "note": "웹 검색으로 공식 문서 인용을 확인한 값. 원문 PDF 대조 전. 부채총계 = 자산총계 297663 - 자본총계 63163 Figures come from WebSearch result summaries of the PDFs (PDFs not opened directly); quotes are as returned by the search. Equity ratio for 31 Mar 2020 not confirmed. Revenue 37,223 from Q3 2020 factsheet column read.",
    "call": null,
    "origin": "outside",
    "updatedAt": "2026-10-26 02:47:05"
   },
   {
    "period": "2019Q4",
    "fiscalLabel": "Q4 2019",
    "reportDate": "",
    "currency": "EUR",
    "values": {
     "revenue": 47127,
     "operatingIncome": 388,
     "totalEquity": 62841,
     "totalLiabilities": 239597
    },
    "raw": {
     "revenue": "FY2019 revenue 172,745 (FY2020 results table); Q4 2019 revenue 47,127",
     "operatingIncome": "Q4 2019 EBIT 388 vs 2,669 (Q4/FY 2019 factsheet, preliminary); FY 4,329",
     "totalEquity": "Equity 62,841 | 66,053",
     "totalLiabilities": "Total assets/balance sheet total 302,438 (Q1 2020 report comparative)"
    },
    "source": "https://group.Mercedes-benz.com/dokumente/investoren/berichte/geschaeftsberichte/daimler/daimler-ir-factsheet-fy-2019-2.pdf https://media.mercedes-benz.it/download/984420/20210218-daimler-ag-table-results-fy-2020.pdf https://annualreport.daimler.com/ar2019/financial-statements/balance-sheet https://group.mercedes-benz.com/documents/investors/reports/interim-reports/q1/daimler-ir-interimreport-q1-2020.pdf",
    "status": "검증 필요",
    "note": "웹 검색으로 공식 문서 인용을 확인한 값. 원문 PDF 대조 전. 부채총계 = 자산총계 302438 - 자본총계 62841 Figures come from WebSearch result summaries of the PDFs (PDFs not opened directly); quotes are as returned by the search. Revenue 47,127 = FY 172,745 minus 9M 125,618 (39,698+42,650+43,270), matches FY2020 table Q4 2019 comparative. EBIT 388 from preliminary factsheet (FY 4,329); FY2020 table shows restated Q4 2019 EBIT 383 (FY 4,313).",
    "call": null,
    "origin": "outside",
    "updatedAt": "2026-10-26 02:47:05"
   },
   {
    "period": "2019Q3",
    "fiscalLabel": "Q3 2019",
    "reportDate": "",
    "currency": "EUR",
    "values": {
     "revenue": 43270,
     "operatingIncome": 2694,
     "totalEquity": 62772,
     "totalLiabilities": 242607
    },
    "raw": {
     "revenue": "Revenue 43,270 40,211 +8",
     "operatingIncome": "EBIT 2,694 2,488 +8",
     "totalEquity": "Total equity | 62,772 | | 66,053",
     "totalLiabilities": "Total equity and liabilities | 305,379 | | 281,619"
    },
    "source": "https://group.mercedes-benz.com/documents/investors/reports/interim-reports/q3/daimler-ir-interimreport-q3-2019.pdf",
    "status": "검증 필요",
    "note": "웹 검색으로 공식 문서 인용을 확인한 값. 원문 PDF 대조 전. 부채총계 = 자산총계 305379 - 자본총계 62772 Figures come from WebSearch result summaries of the PDFs (PDFs not opened directly); quotes are as returned by the search. One snippet read 20.5% vs 20.6%; 62,772/305,379=20.56%. Restated later: Q3 2019 EBIT 2,690.",
    "call": null,
    "origin": "outside",
    "updatedAt": "2026-10-26 02:47:05"
   },
   {
    "period": "2019Q2",
    "fiscalLabel": "Q2 2019",
    "reportDate": "",
    "currency": "EUR",
    "values": {
     "revenue": 42650,
     "operatingIncome": -1555,
     "totalEquity": 61780,
     "totalLiabilities": 232402
    },
    "raw": {
     "revenue": "key figures table lists it as EUR 42,650 million",
     "operatingIncome": "EBIT -1,555 2,640",
     "totalEquity": "Total equity 61,780 | 66,053",
     "totalLiabilities": "Total equity and liabilities 294,182 | 281,619"
    },
    "source": "https://group.mercedes-benz.com/documents/investors/reports/interim-reports/q2/daimler-ir-interimreport-q2-2019.pdf",
    "status": "검증 필요",
    "note": "웹 검색으로 공식 문서 인용을 확인한 값. 원문 PDF 대조 전. 부채총계 = 자산총계 294182 - 자본총계 61780 Figures come from WebSearch result summaries of the PDFs (PDFs not opened directly); quotes are as returned by the search. Restated later: Q2 2019 EBIT -1,558 (Q2 2020 report).",
    "call": null,
    "origin": "outside",
    "updatedAt": "2026-10-26 02:47:05"
   },
   {
    "period": "2019Q1",
    "fiscalLabel": "Q1 2019",
    "reportDate": "",
    "currency": "EUR",
    "values": {
     "revenue": 39698,
     "operatingIncome": 2802,
     "totalEquity": 67866,
     "totalLiabilities": 229631
    },
    "raw": {
     "revenue": "Revenue 39,698 39,785 -0",
     "operatingIncome": "EBIT 2,802 3,335 -16",
     "totalEquity": "Total equity 67,866 | 66,053",
     "totalLiabilities": "Total equity and liabilities 297,497 | 281,619"
    },
    "source": "https://group.mercedes-benz.com/documents/investors/reports/interim-reports/q1/daimler-ir-interimreport-q1-2019.pdf",
    "status": "검증 필요",
    "note": "웹 검색으로 공식 문서 인용을 확인한 값. 원문 PDF 대조 전. 부채총계 = 자산총계 297497 - 자본총계 67866 Figures come from WebSearch result summaries of the PDFs (PDFs not opened directly); quotes are as returned by the search. Restated later: Q1 2019 EBIT 2,798 (2020 reports).",
    "call": null,
    "origin": "outside",
    "updatedAt": "2026-10-26 02:47:05"
   },
   {
    "period": "2018Q4",
    "fiscalLabel": "Q4 2018",
    "reportDate": "",
    "currency": "EUR",
    "values": {
     "revenue": 46610,
     "operatingIncome": 2669,
     "totalEquity": 66053,
     "totalLiabilities": 215566
    },
    "raw": {
     "revenue": "Revenue* ... 46,610 43,613 (Q1 2019 factsheet, Q4 2018 vs Q4 2017)",
     "operatingIncome": "EBIT* ... 2,669 3,421 -22% (Q4 2018 vs Q4 2017)",
     "totalEquity": "Total equity 66,053 (Dec 31, 2018)",
     "totalLiabilities": "Total equity and liabilities 281,619"
    },
    "source": "https://annualreport.daimler.com/ar2018/financial-statements/balance-sheet https://annualreport.daimler.com/ar2018/combined-management-report/financial-position https://group.Mercedes-benz.com/dokumente/investoren/berichte/zwischenberichte/q1/daimler-ir-factsheet-q1-2019.pdf",
    "status": "검증 필요",
    "note": "웹 검색으로 공식 문서 인용을 확인한 값. 원문 PDF 대조 전. 부채총계 = 자산총계 281619 - 자본총계 66053 Figures come from WebSearch result summaries of the PDFs (PDFs not opened directly); quotes are as returned by the search. Q4 from factsheet quarterly columns (consistent with FY 167.4bn / EBIT 11,132). Reported ratio 22.2% differs from 66,053/281,619=23.5%; verify definition.",
    "call": null,
    "origin": "outside",
    "updatedAt": "2026-10-26 02:47:05"
   },
   {
    "period": "2018Q3",
    "fiscalLabel": "Q3 2018",
    "reportDate": "",
    "currency": "EUR",
    "values": {
     "revenue": 40211,
     "operatingIncome": 2488,
     "totalEquity": 65553,
     "totalLiabilities": 211025
    },
    "raw": {
     "revenue": "Revenue* ... 40,211 40,745 (Q1 2019 factsheet); release: 'Group revenue amounted to EUR 40.2 billion'",
     "operatingIncome": "third-quarter EBIT of EUR 2,488 million in 2018",
     "totalEquity": "Total equity 65,553 vs 65,159",
     "totalLiabilities": "Total equity and liabilities 276,578"
    },
    "source": "https://group.mercedes-benz.com/documents/investors/reports/interim-reports/q3/daimler-ir-interimreport-q3-2018.pdf https://s3.observador.pt/wp-content/uploads/2018/10/30134529/daimler_q3_2018_presentation_charts.pdf",
    "status": "검증 필요",
    "note": "웹 검색으로 공식 문서 인용을 확인한 값. 원문 PDF 대조 전. 부채총계 = 자산총계 276578 - 자본총계 65553 Figures come from WebSearch result summaries of the PDFs (PDFs not opened directly); quotes are as returned by the search. Revenue exact from later factsheet comparative.",
    "call": null,
    "origin": "outside",
    "updatedAt": "2026-10-26 02:47:05"
   },
   {
    "period": "2018Q2",
    "fiscalLabel": "Q2 2018",
    "reportDate": "",
    "currency": "EUR",
    "values": {
     "revenue": 40756,
     "operatingIncome": 2640,
     "totalEquity": 64196,
     "totalLiabilities": 205871
    },
    "raw": {
     "revenue": "Revenue* 40,756 41,214 (Q1 2019 factsheet, Q2 2018 vs Q2 2017); release: 'Group revenue amounted to EUR 40.8 billion in the second quarter'",
     "operatingIncome": "second-quarter EBIT of EUR 2,640 million in 2018",
     "totalEquity": "Total equity fell to 64,196",
     "totalLiabilities": "Total equity and liabilities 270,067"
    },
    "source": "https://group.mercedes-benz.com/documents/investors/reports/interim-reports/q2/daimler-ir-interimreport-q2-2018.pdf https://irpages2.eqs.com/download/companies/daimlerchrysler/Presentations/daimler-ir-presentationcharts-q2-2018.pdf https://group.Mercedes-benz.com/dokumente/investoren/berichte/zwischenberichte/q1/daimler-ir-factsheet-q1-2019.pdf",
    "status": "검증 필요",
    "note": "웹 검색으로 공식 문서 인용을 확인한 값. 원문 PDF 대조 전. 부채총계 = 자산총계 270067 - 자본총계 64196 Figures come from WebSearch result summaries of the PDFs (PDFs not opened directly); quotes are as returned by the search. Revenue exact figure from later (Q1 2019) factsheet comparative; equals EUR 40.8bn in own report.",
    "call": null,
    "origin": "outside",
    "updatedAt": "2026-10-26 02:47:05"
   },
   {
    "period": "2018Q1",
    "fiscalLabel": "Q1 2018",
    "reportDate": "",
    "currency": "EUR",
    "values": {
     "revenue": 39785,
     "operatingIncome": 3335,
     "totalEquity": 66887,
     "totalLiabilities": 195900
    },
    "raw": {
     "revenue": "Revenue ... 39,698 39,785 (Q1 2019 vs Q1 2018 comparative, Q1 2019 interim report/factsheet); press release: 'Revenue up by 3% to EUR 39.8 billion'",
     "operatingIncome": "The Daimler Group achieved first-quarter EBIT of EUR 3,335 million in 2018",
     "totalEquity": "Total equity 66,887 vs 65,159 (Dec 31, 2017)",
     "totalLiabilities": "Total equity and liabilities 262,787 vs 255,345"
    },
    "source": "https://group.mercedes-benz.com/documents/investors/reports/interim-reports/q1/daimler-ir-interimreport-q1-2018.pdf https://group.mercedes-benz.com/documents/investors/reports/interim-reports/q1/daimler-ir-interimreport-q1-2019.pdf https://group.Mercedes-benz.com/dokumente/investoren/berichte/zwischenberichte/q1/daimler-ir-factsheet-q1-2018.pdf",
    "status": "검증 필요",
    "note": "웹 검색으로 공식 문서 인용을 확인한 값. 원문 PDF 대조 전. 부채총계 = 자산총계 262787 - 자본총계 66887 Figures come from WebSearch result summaries of the PDFs (PDFs not opened directly); quotes are as returned by the search. Revenue 39,785 is the Q1 2018 comparative shown in 2019 reports (not seen directly in Q1 2018 report; own report says EUR 39.8bn). Reported equity ratio 24.0% does not equal equity/total (25.5%); company ratio definition differs.",
    "call": null,
    "origin": "outside",
    "updatedAt": "2026-10-26 02:47:05"
   },
   {
    "period": "2017Q4",
    "fiscalLabel": "Q4 2017",
    "reportDate": "",
    "currency": "EUR",
    "values": {
     "revenue": 43589,
     "operatingIncome": 3470
    },
    "raw": {
     "revenue": "Factsheet row 43,589 (garbled table); FY revenue 164,330 minus 9M 120,741 = 43,589",
     "operatingIncome": "FY EBIT 14,682 minus 9M 11,212 = 3,470"
    },
    "source": "https://group.Mercedes-benz.com/dokumente/investoren/berichte/geschaeftsberichte/daimler/daimler-ir-factsheet-fy-2017-pre-ifrs.pdf",
    "status": "검증 필요",
    "note": "웹 검색으로 공식 문서 인용을 확인한 값. 원문 PDF 대조 전. 분기 말 자본총계, 자산총계를 확인하지 못해 부채비율 비움 Q4 derived as FY minus 9M (derived, not a quoted Q4 figure). FY2018 report restated 2017 EBIT to 14,348. Dec 31 2017 equity ratio not found.",
    "call": null,
    "origin": "outside",
    "updatedAt": "2026-10-26 02:47:05"
   },
   {
    "period": "2017Q3",
    "fiscalLabel": "Q3 2017",
    "reportDate": "",
    "currency": "EUR",
    "values": {
     "revenue": 40807,
     "operatingIncome": 3458
    },
    "raw": {
     "revenue": "Q3 2017 revenue EUR 40,807 million (Fact Sheet Oct 20 2017)",
     "operatingIncome": "Daimler Group third-quarter EBIT of EUR 3,458 million"
    },
    "source": "https://irpages2.eqs.com/download/companies/daimlerchrysler/Presentations/daimler-ir-presentationcharts-q3-2017.pdf",
    "status": "검증 필요",
    "note": "웹 검색으로 공식 문서 인용을 확인한 값. 원문 PDF 대조 전. 분기 말 자본총계, 자산총계를 확인하지 못해 부채비율 비움 (회사 표기 자기자본비율 24.5%, 정의가 달라 쓰지 않음) 2018 restated Q3 2017 EBIT comparative 3,409 (IFRS 15/9).",
    "call": null,
    "origin": "outside",
    "updatedAt": "2026-10-26 02:47:05"
   },
   {
    "period": "2017Q2",
    "fiscalLabel": "Q2 2017",
    "reportDate": "",
    "currency": "EUR",
    "values": {
     "revenue": 41158,
     "operatingIncome": 3746
    },
    "raw": {
     "revenue": "The factsheet lists it as 41,158 million euros (Group revenue EUR 41.2 billion)",
     "operatingIncome": "The Daimler Group achieved EBIT of EUR 3,746 million in the second quarter"
    },
    "source": "https://irpages2.eqs.com/download/companies/daimlerchrysler/Presentations/daimler-ir-presentationcharts-q2-2017.pdf",
    "status": "검증 필요",
    "note": "웹 검색으로 공식 문서 인용을 확인한 값. 원문 PDF 대조 전. 분기 말 자본총계, 자산총계를 확인하지 못해 부채비율 비움 (회사 표기 자기자본비율 24.6%, 정의가 달라 쓰지 않음)",
    "call": null,
    "origin": "outside",
    "updatedAt": "2026-10-26 02:47:05"
   },
   {
    "period": "2017Q1",
    "fiscalLabel": "Q1 2017",
    "reportDate": "",
    "currency": "EUR",
    "values": {
     "revenue": 38776,
     "operatingIncome": 4008
    },
    "raw": {
     "revenue": "Revenue 38,776 (Q1 2017 factsheet)",
     "operatingIncome": "Group EBIT sums up to EUR 4,008 million (Q1 2016: EUR 2,148 million)"
    },
    "source": "https://irpages2.eqs.com/download/companies/daimlerchrysler/Presentations/daimler-ir-presentationcharts-q1-2017.pdf",
    "status": "검증 필요",
    "note": "웹 검색으로 공식 문서 인용을 확인한 값. 원문 PDF 대조 전. 분기 말 자본총계, 자산총계를 확인하지 못해 부채비율 비움 (회사 표기 자기자본비율 23.6%, 정의가 달라 쓰지 않음)",
    "call": null,
    "origin": "outside",
    "updatedAt": "2026-10-26 02:47:05"
   },
   {
    "period": "2016Q4",
    "fiscalLabel": "Q4 2016",
    "reportDate": "",
    "currency": "EUR",
    "values": {
     "revenue": 41001,
     "operatingIncome": 3459
    },
    "raw": {
     "revenue": "Q4 2016 revenue 41,001 (FY 2016 factsheet, preliminary)",
     "operatingIncome": "Q4 2016 EBIT 3,459 vs 2,901 (FY 2016 factsheet)"
    },
    "source": "https://irpages2.eqs.com/download/companies/daimlerchrysler/Presentations/daimler-ir-factsheet-fy-2016.pdf https://irpages2.eqs.com/download/companies/daimlerchrysler/Presentations/daimler-ir-presentationcharts-q2-2017.pdf",
    "status": "검증 필요",
    "note": "웹 검색으로 공식 문서 인용을 확인한 값. 원문 PDF 대조 전. 분기 말 자본총계, 자산총계를 확인하지 못해 부채비율 비움 (회사 표기 자기자본비율 22.9%, 정의가 달라 쓰지 않음) Factsheet Feb 2017 labelled preliminary/unaudited; year-end ratio taken from 2017 decks. FY2016 EBIT 12,902.",
    "call": null,
    "origin": "outside",
    "updatedAt": "2026-10-26 02:47:05"
   },
   {
    "period": "2016Q3",
    "fiscalLabel": "Q3 2016",
    "reportDate": "",
    "currency": "EUR",
    "values": {
     "revenue": 38597,
     "operatingIncome": 4037
    },
    "raw": {
     "revenue": "Revenue 38,597 (Q3 2016 factsheet)",
     "operatingIncome": "Significant increase in Group EBIT to EUR 4,037 million (Q3 2015: EUR 3,661 million)"
    },
    "source": "https://irpages2.eqs.com/download/companies/daimlerchrysler/Presentations/daimler-ir-presentationcharts-q3-2016.pdf https://irpages2.eqs.com/download/companies/daimlerchrysler/Presentations/daimler-ir-factsheet-q3-2016.pdf",
    "status": "검증 필요",
    "note": "웹 검색으로 공식 문서 인용을 확인한 값. 원문 PDF 대조 전. 분기 말 자본총계, 자산총계를 확인하지 못해 부채비율 비움 (회사 표기 자기자본비율 23.3%, 정의가 달라 쓰지 않음) Later (2018) release restated Q3 2017 comparative, not 2016.",
    "call": null,
    "origin": "outside",
    "updatedAt": "2026-10-26 02:47:05"
   },
   {
    "period": "2016Q2",
    "fiscalLabel": "Q2 2016",
    "reportDate": "",
    "currency": "EUR",
    "values": {
     "revenue": 38616,
     "operatingIncome": 3258
    },
    "raw": {
     "revenue": "Group revenue increased by 3% to EUR 38.6 billion (38,616)",
     "operatingIncome": "Group EBIT for the second quarter amounted to EUR 3,258 million"
    },
    "source": "https://irpages2.eqs.com/download/companies/daimlerchrysler/Presentations/daimler-ir-presentationcharts-q2-2016.pdf",
    "status": "검증 필요",
    "note": "웹 검색으로 공식 문서 인용을 확인한 값. 원문 PDF 대조 전. 분기 말 자본총계, 자산총계를 확인하지 못해 부채비율 비움 (회사 표기 자기자본비율 22.7%, 정의가 달라 쓰지 않음)",
    "call": null,
    "origin": "outside",
    "updatedAt": "2026-10-26 02:47:05"
   },
   {
    "period": "2016Q1",
    "fiscalLabel": "Q1 2016",
    "reportDate": "",
    "currency": "EUR",
    "values": {
     "revenue": 35047,
     "operatingIncome": 2148
    },
    "raw": {
     "revenue": "Revenue up by 2% to EUR 35.0 billion (35,047 in factsheet)",
     "operatingIncome": "Group EBIT for the first quarter of EUR 2,148 million (Q1 2015: EUR 2,906 million)"
    },
    "source": "https://irpages2.eqs.com/download/companies/daimlerchrysler/Presentations/daimler-ir-presentationcharts-q1-2016.pdf",
    "status": "검증 필요",
    "note": "웹 검색으로 공식 문서 인용을 확인한 값. 원문 PDF 대조 전. 분기 말 자본총계, 자산총계를 확인하지 못해 부채비율 비움 (회사 표기 자기자본비율 22.9%, 정의가 달라 쓰지 않음)",
    "call": null,
    "origin": "outside",
    "updatedAt": "2026-10-26 02:47:05"
   },
   {
    "period": "2015Q4",
    "fiscalLabel": "Q4 2015",
    "reportDate": "",
    "currency": "EUR",
    "values": {
     "revenue": 40428,
     "operatingIncome": 2901
    },
    "raw": {
     "revenue": "Revenue 40,428 (Q4 2015 column, Q3 2016 factsheet)",
     "operatingIncome": "EBIT Q4 2015 2,901; FY 13,186 minus 9M 10,285"
    },
    "source": "https://irpages2.eqs.com/download/companies/daimlerchrysler/Presentations/daimler-ir-factsheet-q3-2016.pdf https://irpages2.eqs.com/download/companies/daimlerchrysler/Presentations/daimler-ir-presentationcharts-q1-2016.pdf",
    "status": "검증 필요",
    "note": "웹 검색으로 공식 문서 인용을 확인한 값. 원문 PDF 대조 전. 분기 말 자본총계, 자산총계를 확인하지 못해 부채비율 비움 (회사 표기 자기자본비율 23.6%, 정의가 달라 쓰지 않음) Q4 = FY minus 9M for EBIT (13,186-10,285=2,901). Q1 2016 presentation snippet gave 23.7% for Dec 31 2015; later decks say 23.6%. Year-end ratio not confirmed from the FY2015 report itself.",
    "call": null,
    "origin": "outside",
    "updatedAt": "2026-10-26 02:47:05"
   },
   {
    "period": "2015Q3",
    "fiscalLabel": "Q3 2015",
    "reportDate": "",
    "currency": "EUR",
    "values": {
     "revenue": 37276,
     "operatingIncome": 3661
    },
    "raw": {
     "revenue": "Group revenue of EUR 37.3 billion in the third quarter (37,276 per later factsheet comparative)",
     "operatingIncome": "Group EBIT amounted to EUR 3,661 million in the third quarter"
    },
    "source": "https://irpages2.eqs.com/download/companies/daimlerchrysler/Presentations/2672652_Daimler_Q3_2015_Presentation_Charts.pdf",
    "status": "검증 필요",
    "note": "웹 검색으로 공식 문서 인용을 확인한 값. 원문 PDF 대조 전. 분기 말 자본총계, 자산총계를 확인하지 못해 부채비율 비움 (회사 표기 자기자본비율 24.1%, 정의가 달라 쓰지 않음)",
    "call": null,
    "origin": "outside",
    "updatedAt": "2026-10-26 02:47:05"
   },
   {
    "period": "2015Q2",
    "fiscalLabel": "Q2 2015",
    "reportDate": "",
    "currency": "EUR",
    "values": {
     "revenue": 37527,
     "operatingIncome": 3718
    },
    "raw": {
     "revenue": "Group revenue increased by 19% to EUR 37.5 billion (37,527 per later factsheet comparative)",
     "operatingIncome": "Group EBIT increased by 20% to EUR 3,718 million"
    },
    "source": "https://irpages2.eqs.com/download/companies/daimlerchrysler/Presentations/2642449_Daimler_Q2_2015_Presentation_Charts.pdf",
    "status": "검증 필요",
    "note": "웹 검색으로 공식 문서 인용을 확인한 값. 원문 PDF 대조 전. 분기 말 자본총계, 자산총계를 확인하지 못해 부채비율 비움 (회사 표기 자기자본비율 23.9%, 정의가 달라 쓰지 않음)",
    "call": null,
    "origin": "outside",
    "updatedAt": "2026-10-26 02:47:05"
   },
   {
    "period": "2015Q1",
    "fiscalLabel": "Q1 2015",
    "reportDate": "",
    "currency": "EUR",
    "values": {
     "revenue": 34236,
     "operatingIncome": 2906
    },
    "raw": {
     "revenue": "Group revenue in the first quarter of EUR 34.2 billion (factsheet Q1 2016 comparative 34,236)",
     "operatingIncome": "The Group achieved EBIT of EUR 2,906 million (Q1 2014: EUR 1,787 million)"
    },
    "source": "https://irpages2.eqs.com/download/companies/daimlerchrysler/Presentations/2623383_Daimler_Q1_2015_Presentation_Charts.pdf",
    "status": "검증 필요",
    "note": "웹 검색으로 공식 문서 인용을 확인한 값. 원문 PDF 대조 전. 분기 말 자본총계, 자산총계를 확인하지 못해 부채비율 비움 (회사 표기 자기자본비율 21%, 정의가 달라 쓰지 않음) Equity ratio from Q1 2015 presentation; total equity/assets not retrieved.",
    "call": null,
    "origin": "outside",
    "updatedAt": "2026-10-26 02:47:05"
   }
  ]
 }
});
