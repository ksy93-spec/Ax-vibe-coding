# earnings-archive 업데이트 2026.10.23.1

| 항목 | 값 |
| --- | --- |
| 적용 전 판 | 없음 (VERSION 파일이 없는 처음 판) |
| 적용 후 판 | 2026.10.23.1 |
| 커밋 | 2219b50 → 547fd83 |
| 만든 날 | 2026-10-23 |
| install.bat 다시 실행 | 필요 없음 |

## 적용 방법

1. 이 zip 을 아무 곳에나 풉니다. 바탕화면이나 다운로드 폴더도 됩니다.
2. 풀린 폴더의 `apply.bat` 을 실행합니다.
   처음 판이라 `earnings-archive` 폴더가 없으면 새로 만듭니다. 압축을 푼 폴더 옆(또는 같은 폴더 안)에 생깁니다.
3. 판 번호가 맞으면 파일을 복사하고, 지워진 파일을 정리하고, `VERSION` 을 올립니다.
   판이 맞지 않으면 아무것도 바꾸지 않고 멈춥니다. `updates/README.md` 목록에서 빠진 업데이트부터 순서대로 적용하세요.
4. 킷 폴더의 `index.html` 을 Chrome 이나 Edge 로 엽니다. 설치 단계는 없습니다.

적용이 끝나면 풀었던 폴더는 지워도 됩니다.

## 이번에 바뀐 내용

- 547fd83 kit(earnings-archive): 주요 고객 실적 자료 첫 판

## 파일 목록

### 추가 (169개)

- `.clinerules`
- `MANIFEST.md`
- `OFFLINE.md`
- `PROMPT.md`
- `SPEC.md`
- `assets/css/app.css`
- `assets/css/ea.css`
- `assets/css/tokens.css`
- `assets/fonts/pretendard/LICENSE.txt`
- `assets/fonts/pretendard/PretendardVariable.subset.0.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.1.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.10.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.11.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.12.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.13.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.14.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.15.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.16.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.17.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.18.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.19.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.2.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.20.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.21.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.22.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.23.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.24.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.25.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.26.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.27.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.28.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.29.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.3.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.30.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.31.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.32.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.33.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.34.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.35.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.36.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.37.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.38.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.39.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.4.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.40.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.41.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.42.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.43.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.44.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.45.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.46.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.47.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.48.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.49.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.5.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.50.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.51.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.52.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.53.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.54.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.55.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.56.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.57.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.58.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.59.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.6.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.60.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.61.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.62.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.63.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.64.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.65.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.66.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.67.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.68.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.69.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.7.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.70.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.71.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.72.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.73.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.74.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.75.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.76.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.77.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.78.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.79.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.8.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.80.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.81.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.82.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.83.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.84.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.85.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.86.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.87.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.88.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.89.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.9.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.90.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.91.woff2`
- `assets/fonts/pretendard/font.css`
- `assets/licenses/simple-icons-CC0.txt`
- `assets/licenses/simple-icons-DISCLAIMER.md`
- `assets/logos/SOURCES.md`
- `assets/logos/audi.svg`
- `assets/logos/bmw.svg`
- `assets/logos/gm.svg`
- `assets/logos/honda.svg`
- `assets/logos/hyundai.svg`
- `assets/logos/kia.svg`
- `assets/logos/porsche.svg`
- `assets/logos/tesla.svg`
- `assets/logos/toyota.svg`
- `assets/logos/volvo.svg`
- `assets/logos/vw.svg`
- `data/companies.js`
- `data/fx.js`
- `data/reports/alps.js`
- `data/reports/audi.js`
- `data/reports/aumovio.js`
- `data/reports/bmw.js`
- `data/reports/denso.js`
- `data/reports/gm.js`
- `data/reports/honda.js`
- `data/reports/hyundai.js`
- `data/reports/jlr.js`
- `data/reports/kia.js`
- `data/reports/mercedes.js`
- `data/reports/porsche.js`
- `data/reports/tesla.js`
- `data/reports/toyota.js`
- `data/reports/visteon.js`
- `data/reports/volvo.js`
- `data/reports/vw.js`
- `data/transcripts/README.md`
- `index.html`
- `packs/README.md`
- `prompts/00-project-instructions.md`
- `prompts/10-call-summary.md`
- `prompts/11-numbers.md`
- `prompts/20-screen-change.md`
- `prompts/40-fix-error.md`
- `prompts/README.md`
- `src/lib/csv.js`
- `src/lib/dom.js`
- `src/lib/store.js`
- `src/lib/ui.js`
- `src/main.js`
- `src/model/core.js`
- `src/model/files.js`
- `src/model/merge.js`
- `src/model/parse.js`
- `src/model/prompt.js`
- `src/ui/chart.js`
- `src/ui/format.js`
- `src/ui/state.js`
- `src/ui/view-admin.js`
- `src/ui/view-company.js`
- `src/ui/view-edit.js`
- `src/ui/view-import.js`
- `src/ui/view-overview.js`
- `src/ui/view-search.js`
- `tests/fixtures/sample-answers.md`
- `tests/fixtures/sample-transcript.txt`
- `tests/index.html`
- `tests/model.test.js`
- `tests/run.cjs`
- `types/ea.d.ts`

### 수정 (0개)

- 없음

### 삭제 (0개)

- 없음

