# earnings-archive 업데이트 2026.10.26.1

| 항목 | 값 |
| --- | --- |
| 적용 전 판 | 2026.10.23.2 |
| 적용 후 판 | 2026.10.26.1 |
| 커밋 | 105aa51 → 2ca58d7 |
| 만든 날 | 2026-10-26 |
| install.bat 다시 실행 | 필요 없음 |

## 적용 방법

1. 이 zip 을 아무 곳에나 풉니다. 바탕화면이나 다운로드 폴더도 됩니다.
2. 풀린 폴더의 `apply.bat` 을 실행합니다.
   `earnings-archive` 폴더는 이 폴더 안, 옆, 한두 단계 위에서 찾습니다. 못 찾으면 탐색기에서 `earnings-archive` 폴더를 검은 창으로 끌어다 놓고 Enter 를 누릅니다.
3. 판 번호가 맞으면 파일을 복사하고, 지워진 파일을 정리하고, `VERSION` 을 올립니다.
   판이 맞지 않으면 아무것도 바꾸지 않고 멈춥니다. `updates/README.md` 목록에서 빠진 업데이트부터 순서대로 적용하세요.
4. 킷 폴더의 `index.html` 을 Chrome 이나 Edge 로 엽니다. 설치 단계는 없습니다.

적용이 끝나면 풀었던 폴더는 지워도 됩니다.

## 이번에 바뀐 내용

- 2ca58d7 kit(earnings-archive): Mercedes-Benz 2015 Q1 ~ 2026 Q2 숫자 묶음 추가

## 파일 목록

### 추가 (2개)

- `packs/ea-pack-20261026-mercedes.json`
- `packs/mercedes-2015q1-2026q2.csv`

### 수정 (2개)

- `MANIFEST.md`
- `packs/README.md`

### 삭제 (0개)

- 없음

