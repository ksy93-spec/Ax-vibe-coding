# web-tool-starter

브라우저에서 바로 열리는 사내 도구 뼈대. 빌드 단계와 패키지 설치가 없습니다.

## 실행 환경

- Node: 불필요
- Python: 불필요 (선택: 로컬 서버로 열 때만)
- 브라우저: Chromium 기반 (Chrome, Edge) 또는 Firefox. `file://` 로 직접 열립니다.
- 빌드 단계: 없음

## 반입 방식

C. npm 의존성이 0개입니다. 반입되는 것은 소스 텍스트와 글꼴 파일뿐입니다.

## 포함된 의존성

npm 패키지 없음. 아래는 코드가 아닌 자산입니다.

| 파일 | 출처 | 버전 | 라이선스(SPDX) | 원문 |
| --- | --- | --- | --- | --- |
| `assets/fonts/pretendard/` (woff2 92개, font.css) | Pretendard (Kil Hyung-jin), npm `pretendard@1.3.9` 의 공식 가변 분할 파일 | 1.3.9 원본 그대로 | OFL-1.1 | `assets/fonts/pretendard/LICENSE.txt` (tarball 의 `package/dist/LICENSE.txt`) |

글꼴은 배포처가 글자 범위별로 나눠 둔 공식 파일 92개(2.8MB)를 고치지 않고 넣었습니다. 화면에 나온 글자가 든 파일만 읽힙니다.
Pretendard 라이선스는 고친 글꼴에 "Pretendard" 이름을 쓰지 못하게 하므로(예약 글꼴 이름), 직접 서브셋한 파일은 쓰지 않습니다.
굵기는 45~930 연속입니다.

## 구성

| 경로 | 내용 | 사내에서 수정 |
| --- | --- | --- |
| `index.html` | 진입점. 스크립트 로드 순서가 중요합니다. | 스크립트 추가할 때만 |
| `src/main.js` | 앱 로직. 여기부터 고칩니다. | 예 |
| `src/lib/dom.js` | 엘리먼트 생성 헬퍼 | 아니오 |
| `src/lib/store.js` | 상태 저장소 | 아니오 |
| `src/lib/csv.js` | CSV 파싱, 인코딩 판별, 내보내기 | 아니오 |
| `src/lib/ui.js` | 토스트, 모달, 확인창 | 아니오 |
| `src/lib/table.js` | 정렬/검색/페이지 표 | 아니오 |
| `assets/css/tokens.css` | 디자인 토큰 | 브랜드 색만 |
| `assets/css/app.css` | 컴포넌트 스타일 | 예 |
| `types/app.d.ts` | 타입 참조 | 아니오 |

## 이 킷이 대신 해결해 둔 것

폐쇄망에서 직접 부딪히면 시간을 잡아먹는 것들입니다.

- CP949(EUC-KR) 로 저장된 CSV 자동 판별. 사내 시스템에서 내려받은 파일 상당수가 CP949 입니다.
- 내보낼 때 UTF-8 BOM 부착. BOM 이 없으면 엑셀에서 한글이 전부 깨집니다.
- 따옴표 안의 쉼표와 줄바꿈 처리. 직접 `split(',')` 로 짜면 여기서 데이터가 밀립니다.
- ES 모듈 대신 클래식 스크립트. `file://` 로 열 때 ES 모듈은 CORS 로 막힙니다.
- 다운로드 파일명에서 한글 제거. 크로미움은 `<a download>` 에 한글이 섞이면 이름을 통째로
  버리고 확장자 없는 `download` 파일을 떨굽니다.
- 한글 본문 행간과 자간 조정.

## 사내에서 할 일

- [ ] `src/main.js` 의 `render()` 를 실제 화면으로 교체
- [ ] `assets/css/app.css` 에 필요한 컴포넌트 추가
- [ ] 브랜드 색이 있으면 `tokens.css` 의 `--c-accent` 계열 3개만 교체
- [ ] `index.html` 의 `<title>` 과 헤더 문구 변경

## 검증 기록

2026-09-24, 헤드리스 Chromium 에서 `file://` 로 확인.
폰트 로드, CP949 CSV 240행 읽기, 숫자 정렬, 검색, BOM 붙은 내보내기, 모달 열고 닫기,
다크 모드 전환, 콘솔 에러 없음, 1280px 와 390px 에서 가로 스크롤 없음.
