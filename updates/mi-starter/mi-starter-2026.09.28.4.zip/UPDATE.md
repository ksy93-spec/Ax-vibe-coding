# mi-starter 업데이트 2026.09.28.4

| 항목 | 값 |
| --- | --- |
| 적용 전 판 | 2026.09.28.3 |
| 적용 후 판 | 2026.09.28.4 |
| 커밋 | 2d1bfa6 → 446f29b |
| 만든 날 | 2026-09-28 |
| install.bat 다시 실행 | 필요 없음 |

## 적용 방법

1. 이 zip 을 아무 곳에나 풉니다. 바탕화면이나 다운로드 폴더도 됩니다.
2. 풀린 폴더의 `apply.bat` 을 실행합니다.
   `mi-starter` 폴더를 자동으로 찾지 못하면, 탐색기에서 `mi-starter` 폴더를 검은 창으로 끌어다 놓고 Enter 를 누릅니다.
3. 판 번호가 맞으면 파일을 복사하고, 지워진 파일을 정리하고, `VERSION` 을 올립니다.
   판이 맞지 않으면 아무것도 바꾸지 않고 멈춥니다. `updates/README.md` 목록에서 빠진 업데이트부터 순서대로 적용하세요.
4. `build.bat` 을 실행해 검사와 빌드가 통과하는지 봅니다.

적용이 끝나면 풀었던 폴더는 지워도 됩니다.

## 이번에 바뀐 내용

- d72adab kit(mi-starter): Pretendard 를 공식 분할 파일로 교체

## 파일 목록

### 추가 (95개)

- `public/fonts/pretendard/LICENSE.txt`
- `public/fonts/pretendard/PretendardVariable.subset.0.woff2`
- `public/fonts/pretendard/PretendardVariable.subset.1.woff2`
- `public/fonts/pretendard/PretendardVariable.subset.10.woff2`
- `public/fonts/pretendard/PretendardVariable.subset.11.woff2`
- `public/fonts/pretendard/PretendardVariable.subset.12.woff2`
- `public/fonts/pretendard/PretendardVariable.subset.13.woff2`
- `public/fonts/pretendard/PretendardVariable.subset.14.woff2`
- `public/fonts/pretendard/PretendardVariable.subset.15.woff2`
- `public/fonts/pretendard/PretendardVariable.subset.16.woff2`
- `public/fonts/pretendard/PretendardVariable.subset.17.woff2`
- `public/fonts/pretendard/PretendardVariable.subset.18.woff2`
- `public/fonts/pretendard/PretendardVariable.subset.19.woff2`
- `public/fonts/pretendard/PretendardVariable.subset.2.woff2`
- `public/fonts/pretendard/PretendardVariable.subset.20.woff2`
- `public/fonts/pretendard/PretendardVariable.subset.21.woff2`
- `public/fonts/pretendard/PretendardVariable.subset.22.woff2`
- `public/fonts/pretendard/PretendardVariable.subset.23.woff2`
- `public/fonts/pretendard/PretendardVariable.subset.24.woff2`
- `public/fonts/pretendard/PretendardVariable.subset.25.woff2`
- `public/fonts/pretendard/PretendardVariable.subset.26.woff2`
- `public/fonts/pretendard/PretendardVariable.subset.27.woff2`
- `public/fonts/pretendard/PretendardVariable.subset.28.woff2`
- `public/fonts/pretendard/PretendardVariable.subset.29.woff2`
- `public/fonts/pretendard/PretendardVariable.subset.3.woff2`
- `public/fonts/pretendard/PretendardVariable.subset.30.woff2`
- `public/fonts/pretendard/PretendardVariable.subset.31.woff2`
- `public/fonts/pretendard/PretendardVariable.subset.32.woff2`
- `public/fonts/pretendard/PretendardVariable.subset.33.woff2`
- `public/fonts/pretendard/PretendardVariable.subset.34.woff2`
- `public/fonts/pretendard/PretendardVariable.subset.35.woff2`
- `public/fonts/pretendard/PretendardVariable.subset.36.woff2`
- `public/fonts/pretendard/PretendardVariable.subset.37.woff2`
- `public/fonts/pretendard/PretendardVariable.subset.38.woff2`
- `public/fonts/pretendard/PretendardVariable.subset.39.woff2`
- `public/fonts/pretendard/PretendardVariable.subset.4.woff2`
- `public/fonts/pretendard/PretendardVariable.subset.40.woff2`
- `public/fonts/pretendard/PretendardVariable.subset.41.woff2`
- `public/fonts/pretendard/PretendardVariable.subset.42.woff2`
- `public/fonts/pretendard/PretendardVariable.subset.43.woff2`
- `public/fonts/pretendard/PretendardVariable.subset.44.woff2`
- `public/fonts/pretendard/PretendardVariable.subset.45.woff2`
- `public/fonts/pretendard/PretendardVariable.subset.46.woff2`
- `public/fonts/pretendard/PretendardVariable.subset.47.woff2`
- `public/fonts/pretendard/PretendardVariable.subset.48.woff2`
- `public/fonts/pretendard/PretendardVariable.subset.49.woff2`
- `public/fonts/pretendard/PretendardVariable.subset.5.woff2`
- `public/fonts/pretendard/PretendardVariable.subset.50.woff2`
- `public/fonts/pretendard/PretendardVariable.subset.51.woff2`
- `public/fonts/pretendard/PretendardVariable.subset.52.woff2`
- `public/fonts/pretendard/PretendardVariable.subset.53.woff2`
- `public/fonts/pretendard/PretendardVariable.subset.54.woff2`
- `public/fonts/pretendard/PretendardVariable.subset.55.woff2`
- `public/fonts/pretendard/PretendardVariable.subset.56.woff2`
- `public/fonts/pretendard/PretendardVariable.subset.57.woff2`
- `public/fonts/pretendard/PretendardVariable.subset.58.woff2`
- `public/fonts/pretendard/PretendardVariable.subset.59.woff2`
- `public/fonts/pretendard/PretendardVariable.subset.6.woff2`
- `public/fonts/pretendard/PretendardVariable.subset.60.woff2`
- `public/fonts/pretendard/PretendardVariable.subset.61.woff2`
- `public/fonts/pretendard/PretendardVariable.subset.62.woff2`
- `public/fonts/pretendard/PretendardVariable.subset.63.woff2`
- `public/fonts/pretendard/PretendardVariable.subset.64.woff2`
- `public/fonts/pretendard/PretendardVariable.subset.65.woff2`
- `public/fonts/pretendard/PretendardVariable.subset.66.woff2`
- `public/fonts/pretendard/PretendardVariable.subset.67.woff2`
- `public/fonts/pretendard/PretendardVariable.subset.68.woff2`
- `public/fonts/pretendard/PretendardVariable.subset.69.woff2`
- `public/fonts/pretendard/PretendardVariable.subset.7.woff2`
- `public/fonts/pretendard/PretendardVariable.subset.70.woff2`
- `public/fonts/pretendard/PretendardVariable.subset.71.woff2`
- `public/fonts/pretendard/PretendardVariable.subset.72.woff2`
- `public/fonts/pretendard/PretendardVariable.subset.73.woff2`
- `public/fonts/pretendard/PretendardVariable.subset.74.woff2`
- `public/fonts/pretendard/PretendardVariable.subset.75.woff2`
- `public/fonts/pretendard/PretendardVariable.subset.76.woff2`
- `public/fonts/pretendard/PretendardVariable.subset.77.woff2`
- `public/fonts/pretendard/PretendardVariable.subset.78.woff2`
- `public/fonts/pretendard/PretendardVariable.subset.79.woff2`
- `public/fonts/pretendard/PretendardVariable.subset.8.woff2`
- `public/fonts/pretendard/PretendardVariable.subset.80.woff2`
- `public/fonts/pretendard/PretendardVariable.subset.81.woff2`
- `public/fonts/pretendard/PretendardVariable.subset.82.woff2`
- `public/fonts/pretendard/PretendardVariable.subset.83.woff2`
- `public/fonts/pretendard/PretendardVariable.subset.84.woff2`
- `public/fonts/pretendard/PretendardVariable.subset.85.woff2`
- `public/fonts/pretendard/PretendardVariable.subset.86.woff2`
- `public/fonts/pretendard/PretendardVariable.subset.87.woff2`
- `public/fonts/pretendard/PretendardVariable.subset.88.woff2`
- `public/fonts/pretendard/PretendardVariable.subset.89.woff2`
- `public/fonts/pretendard/PretendardVariable.subset.9.woff2`
- `public/fonts/pretendard/PretendardVariable.subset.90.woff2`
- `public/fonts/pretendard/PretendardVariable.subset.91.woff2`
- `public/fonts/pretendard/font.css`
- `src/lib/font.js`

### 수정 (5개)

- `MANIFEST.md`
- `OFFLINE.md`
- `demo/index.html`
- `src/index.css`
- `src/main.jsx`

### 삭제 (1개)

- `src/assets/PretendardVariable.subset.woff2`

