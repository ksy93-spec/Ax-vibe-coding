# demand-sim 업데이트 2026.10.01.2

| 항목 | 값 |
| --- | --- |
| 적용 전 판 | 2026.10.01.1 |
| 적용 후 판 | 2026.10.01.2 |
| 커밋 | dc45d5a → bcbde66 |
| 만든 날 | 2026-10-01 |
| install.bat 다시 실행 | 필요 없음 |

## 적용 방법

1. 이 zip 을 아무 곳에나 풉니다. 바탕화면이나 다운로드 폴더도 됩니다.
2. 풀린 폴더의 `apply.bat` 을 실행합니다.
   `demand-sim` 폴더를 자동으로 찾지 못하면, 탐색기에서 `demand-sim` 폴더를 검은 창으로 끌어다 놓고 Enter 를 누릅니다.
3. 판 번호가 맞으면 파일을 복사하고, 지워진 파일을 정리하고, `VERSION` 을 올립니다.
   판이 맞지 않으면 아무것도 바꾸지 않고 멈춥니다. `updates/README.md` 목록에서 빠진 업데이트부터 순서대로 적용하세요.
4. `build.bat` 을 실행해 검사와 빌드가 통과하는지 봅니다.

적용이 끝나면 풀었던 폴더는 지워도 됩니다.

## 이번에 바뀐 내용

- 595f435 kit(demand-sim): 한눈에 보기(세계 지도, 도넛, 우리 디스플레이 점유율), 쉬운 말

## 파일 목록

### 추가 (9개)

- `assets/licenses/i18n-iso-countries-MIT.txt`
- `assets/licenses/world-atlas-ISC.txt`
- `src/model/countries.js`
- `src/model/display.js`
- `src/model/geo.js`
- `src/ui/donut.js`
- `src/ui/map.js`
- `src/ui/view-overview.js`
- `src/ui/worldmap-data.js`

### 수정 (32개)

- `.clinerules`
- `MANIFEST.md`
- `OFFLINE.md`
- `SPEC.md`
- `assets/css/sim.css`
- `index.html`
- `prompts/00-project-instructions.md`
- `prompts/10-column-names.md`
- `prompts/20-screen-change.md`
- `prompts/30-new-preset.md`
- `prompts/40-fix-error.md`
- `prompts/README.md`
- `src/main.js`
- `src/model/engine.js`
- `src/model/prep.js`
- `src/model/presets.js`
- `src/model/sample.js`
- `src/model/shocks.js`
- `src/ui/chart.js`
- `src/ui/format.js`
- `src/ui/io.js`
- `src/ui/state.js`
- `src/ui/view-data.js`
- `src/ui/view-report.js`
- `src/ui/view-result.js`
- `src/ui/view-scenario.js`
- `src/ui/widgets.js`
- `tests/index.html`
- `tests/model.test.js`
- `tests/run.cjs`
- `types/app.d.ts`
- `types/sim.d.ts`

### 삭제 (0개)

- 없음

