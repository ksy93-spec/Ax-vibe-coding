@echo off
chcp 65001 >nul
setlocal
REM demand-sim 업데이트 2026.10.01.1. zip 을 아무 곳에나 푼 뒤 이 파일을 실행합니다.
REM 킷 폴더를 끌어다 놓아 실행해도 됩니다: apply.bat <demand-sim 폴더>
set "KIT="
if not "%~1"=="" call :try "%~1"
call :try "%~dp0.."
call :try "%~dp0..\.."
call :try "%~dp0..\demand-sim"
call :try "%~dp0..\..\demand-sim"
if defined KIT goto found
echo demand-sim 폴더를 찾지 못했습니다.
echo 탐색기에서 demand-sim 폴더를 이 창으로 끌어다 놓고 Enter 를 누르세요.
set /p "ASK=폴더: "
if not defined ASK goto notkit
set "ASK=%ASK:"=%"
call :try "%ASK%"
if not defined KIT goto notkit
:found
if "%KIT:~-1%"=="\" set "KIT=%KIT:~0,-1%"
echo 킷 폴더: %KIT%
set "CUR="
if exist "%KIT%\VERSION" for /f "usebackq delims=" %%v in ("%KIT%\VERSION") do if not defined CUR set "CUR=%%v"
if defined CUR goto wrongver
if exist "%~dp0files" robocopy "%~dp0files" "%KIT%" /e /r:1 /w:1 /njh /njs /ndl /nfl /np >nul
if errorlevel 8 goto copyfail
>"%KIT%\VERSION" echo 2026.10.01.1
echo.
echo 적용했습니다. 판: 2026.10.01.1
echo 바뀐 파일 137개, 지운 파일 0개
echo 다음: build.bat 으로 검사와 빌드를 확인하세요.
pause
exit /b 0

:try
if defined KIT goto :eof
if not exist "%~1\MANIFEST.md" goto :eof
findstr /b /c:"# demand-sim" "%~1\MANIFEST.md" >nul 2>nul && set "KIT=%~f1"
goto :eof

:notkit
echo demand-sim 킷 폴더가 아닙니다. MANIFEST.md 가 있는 demand-sim 폴더를 지정하세요.
pause
exit /b 1

:wrongver
echo 지금 판은 [%CUR%] 인데 이 업데이트는 (VERSION 파일 없음) 에 적용하는 것입니다.
echo 아무것도 바꾸지 않았습니다. updates\README.md 목록에서 빠진 업데이트부터 순서대로 적용하세요.
pause
exit /b 1

:copyfail
echo 파일 복사에 실패했습니다. 킷 폴더의 파일이 다른 프로그램에서 열려 있지 않은지 확인하세요.
pause
exit /b 1
