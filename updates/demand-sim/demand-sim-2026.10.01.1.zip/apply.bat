@echo off
chcp 65001 >nul
setlocal
REM demand-sim 업데이트 2026.10.01.1. zip 을 아무 곳에나 푼 뒤 이 파일을 실행합니다.
REM 킷 폴더를 끌어다 놓아 실행해도 됩니다: apply.bat <demand-sim 폴더>
set "KIT="
if not "%~1"=="" call :try "%~1"
call :try "%~dp0demand-sim"
call :try "%~dp0."
call :try "%~dp0.."
call :try "%~dp0..\demand-sim"
call :try "%~dp0..\.."
call :try "%~dp0..\..\demand-sim"
if defined KIT goto found
for %%I in ("%~dp0.") do set "HERE=%%~nxI"
set "PFX=%HERE:~0,11%"
set "NEW=%~dp0demand-sim"
if /i "%PFX%"=="demand-sim-" set "NEW=%~dp0..\demand-sim"
for %%I in ("%NEW%") do set "NEW=%%~fI"
if exist "%NEW%\" goto newexists
echo demand-sim 폴더가 없어 새로 설치합니다: %NEW%
mkdir "%NEW%" 2>nul
if not exist "%NEW%\" goto copyfail
set "KIT=%NEW%"
goto found
echo demand-sim 폴더를 찾지 못했습니다.
echo 찾아본 곳: %~dp0demand-sim, %~dp0..\demand-sim, %~dp0..\..\demand-sim
if exist "%~dp0..\demand-sim\files\MANIFEST.md" echo 참고: %~dp0..\demand-sim 는 킷이 아니라 업데이트 zip 을 푼 폴더로 보입니다. 처음 판 zip 의 apply.bat 을 먼저 실행하세요.
echo 탐색기에서 demand-sim 폴더를 이 창으로 끌어다 놓고 Enter 를 누르세요.
set /p "ASK=폴더: "
if not defined ASK goto notkit
set "ASK=%ASK:"=%"
call :try "%ASK%"
if not defined KIT goto notkit
:found
if "%KIT:~-1%"=="\" set "KIT=%KIT:~0,-1%"
echo 킷 폴더: %KIT%
set "CUR="
if exist "%KIT%\VERSION" for /f "usebackq delims=" %%v in ("%KIT%\VERSION") do if not defined CUR set "CUR=%%v"
if defined CUR goto wrongver
if exist "%~dp0files" robocopy "%~dp0files" "%KIT%" /e /r:1 /w:1 /njh /njs /ndl /nfl /np >nul
if errorlevel 8 goto copyfail
>"%KIT%\VERSION" echo 2026.10.01.1
echo.
echo 적용했습니다. 판: 2026.10.01.1
echo 바뀐 파일 137개, 지운 파일 0개
echo 킷 폴더: %KIT%
echo 다음: 킷 폴더의 index.html 을 Chrome 이나 Edge 로 여세요. 설치할 것은 없습니다.
pause
exit /b 0

:try
if defined KIT goto :eof
if not exist "%~1\MANIFEST.md" goto :eof
findstr /b /c:"# demand-sim" "%~1\MANIFEST.md" >nul 2>nul && set "KIT=%~f1"
goto :eof

:notkit
echo demand-sim 킷 폴더가 아닙니다. MANIFEST.md 가 있는 demand-sim 폴더를 지정하세요.
pause
exit /b 1

:newexists
echo %NEW% 폴더가 이미 있지만 demand-sim 킷 폴더가 아닙니다 (MANIFEST.md 가 없거나 다릅니다).
echo 그 폴더 이름을 바꾸거나 지운 뒤 다시 실행하세요. 아무것도 바꾸지 않았습니다.
pause
exit /b 1

:wrongver
echo 지금 판은 [%CUR%] 인데 이 업데이트는 (VERSION 파일 없음) 에 적용하는 것입니다.
echo 아무것도 바꾸지 않았습니다. updates\README.md 목록에서 빠진 업데이트부터 순서대로 적용하세요.
pause
exit /b 1

:copyfail
echo 파일 복사에 실패했습니다. 킷 폴더의 파일이 다른 프로그램에서 열려 있지 않은지 확인하세요.
pause
exit /b 1
