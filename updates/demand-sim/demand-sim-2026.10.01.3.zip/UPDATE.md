# demand-sim 업데이트 2026.10.01.3

| 항목 | 값 |
| --- | --- |
| 적용 전 판 | 2026.10.01.2 |
| 적용 후 판 | 2026.10.01.3 |
| 커밋 | bcbde66 → e044251 |
| 만든 날 | 2026-10-01 |
| install.bat 다시 실행 | 필요 없음 |

## 적용 방법

1. 이 zip 을 아무 곳에나 풉니다. 바탕화면이나 다운로드 폴더도 됩니다.
2. 풀린 폴더의 `apply.bat` 을 실행합니다.
   `demand-sim` 폴더는 이 폴더 안, 옆, 한두 단계 위에서 찾습니다. 못 찾으면 탐색기에서 `demand-sim` 폴더를 검은 창으로 끌어다 놓고 Enter 를 누릅니다.
3. 판 번호가 맞으면 파일을 복사하고, 지워진 파일을 정리하고, `VERSION` 을 올립니다.
   판이 맞지 않으면 아무것도 바꾸지 않고 멈춥니다. `updates/README.md` 목록에서 빠진 업데이트부터 순서대로 적용하세요.
4. 킷 폴더의 `index.html` 을 Chrome 이나 Edge 로 엽니다. 설치 단계는 없습니다.

적용이 끝나면 풀었던 폴더는 지워도 됩니다.

## 이번에 바뀐 내용

- 331885e kit(demand-sim): 기타 지역, 2028-12 연 단위 전망, Worst/Base/Best, 임원 보고서

## 파일 목록

### 추가 (3개)

- `src/model/annual.js`
- `src/model/scenarios.js`
- `src/ui/bars.js`

### 수정 (32개)

- `.clinerules`
- `MANIFEST.md`
- `OFFLINE.md`
- `SPEC.md`
- `assets/css/sim.css`
- `index.html`
- `prompts/00-project-instructions.md`
- `prompts/20-screen-change.md`
- `prompts/30-new-preset.md`
- `src/main.js`
- `src/model/baseline.js`
- `src/model/display.js`
- `src/model/geo.js`
- `src/model/prep.js`
- `src/model/presets.js`
- `src/model/sample.js`
- `src/model/shocks.js`
- `src/ui/chart.js`
- `src/ui/format.js`
- `src/ui/io.js`
- `src/ui/map.js`
- `src/ui/state.js`
- `src/ui/view-data.js`
- `src/ui/view-overview.js`
- `src/ui/view-report.js`
- `src/ui/view-result.js`
- `src/ui/view-scenario.js`
- `tests/index.html`
- `tests/model.test.js`
- `tests/run.cjs`
- `types/app.d.ts`
- `types/sim.d.ts`

### 삭제 (0개)

- 없음

