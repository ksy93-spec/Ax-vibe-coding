# 예시 카드 추가

분석가들이 반복해서 쓰는 카드(예: 특정 국가 보조금 개편)를 "예시에서 추가" 목록에 넣습니다.
날짜와 크기는 자리표시로 두고, 근거 칸에 무엇을 확인해야 하는지 적습니다.

```
파일: src/model/presets.js
목표: sim.presets 배열 끝에 카드 하나를 더한다.

이미 정해진 것 (바꾸지 말 것):
- 항목 모양: { key: string, label: string, make: function (ds, bl) { return 카드 } }
- 카드 모양은 types/sim.d.ts 의 Sim.ShockCard. base(ds, layer, patch) 가 빈 카드에 patch 를 덮어 만든다.
- 단위: TIV 는 %, POWERTRAIN 은 %p, BRAND 는 상대 %
- 시작 월은 firstForecast(ds) 에서 상대로 잡는다 (U.addMonths). 실제 날짜를 박지 않는다.
  데이터마다 예측 시작 월이 달라서, 박아 두면 실적 기간 안으로 들어가는 경우가 생긴다.
- 이름은 '(예시) ' 로 시작한다. 보고서가 이 표시를 보고 경고를 띄운다.

추가할 카드:
- 이름: 〈예: (예시) 국가 보조금 개편〉
- 대상: 〈예: POWERTRAIN, BEV〉 (TIV = 시장 TAM, POWERTRAIN = Powertrain 비중, BRAND = OEM M/S)
- 지역과 국가 한정: 〈예: regionFor(ds, 'EU'), 국가 한정 없음〉
- 영향 크기 범위 최소 / 예상 / 범위 최대: 〈예: -4 / -2 / 0〉 (Worst / Best 는 자동)
- 시점: 〈예: 전망 시작 +3개월, 즉시, 지속, Pull-forward 2개월 +10%〉
- 근거 칸 문구: 〈예: 개편 고시일, 차종별 보조금 차이를 확인해 넣으세요.〉

완료 기준:
- tests/index.html 23/23 통과 ("예시 카드는 모두 오류 없이 만들어진다" 포함)
- 시나리오 탭 "예시에서 추가..." 목록에 새 카드가 보이고, 편집 창 점검에 오류가 없다
```
