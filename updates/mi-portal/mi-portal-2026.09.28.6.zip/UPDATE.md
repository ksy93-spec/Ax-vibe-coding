# mi-portal 업데이트 2026.09.28.6

| 항목 | 값 |
| --- | --- |
| 적용 전 판 | 2026.09.28.5 |
| 적용 후 판 | 2026.09.28.6 |
| 커밋 | 9c49a77 → 6e1e6d7 |
| 만든 날 | 2026-09-28 |
| install.bat 다시 실행 | 필요 없음 |

## 적용 방법

1. 이 zip 을 아무 곳에나 풉니다. 바탕화면이나 다운로드 폴더도 됩니다.
2. 풀린 폴더의 `apply.bat` 을 실행합니다.
   `mi-portal` 폴더를 자동으로 찾지 못하면, 탐색기에서 `mi-portal` 폴더를 검은 창으로 끌어다 놓고 Enter 를 누릅니다.
3. 판 번호가 맞으면 파일을 복사하고, 지워진 파일을 정리하고, `VERSION` 을 올립니다.
   판이 맞지 않으면 아무것도 바꾸지 않고 멈춥니다. `updates/README.md` 목록에서 빠진 업데이트부터 순서대로 적용하세요.
4. `build.bat` 을 실행해 검사와 빌드가 통과하는지 봅니다.

적용이 끝나면 풀었던 폴더는 지워도 됩니다.

## 이번에 바뀐 내용

- 415f94a kit(mi-portal): 포탈 단추로 PC 의 exe 프로그램 실행

## 파일 목록

### 추가 (7개)

- `public/launcher/README.md`
- `public/launcher/apps.ini`
- `public/launcher/launcher.ps1`
- `public/launcher/register.bat`
- `public/launcher/unregister.bat`
- `src/features/apps/exe-app-page.tsx`
- `src/features/apps/launch.ts`

### 수정 (12개)

- `MANIFEST.md`
- `NOTICE.md`
- `OFFLINE.md`
- `README.md`
- `demo/index.html`
- `prompts/30-connect-app.md`
- `src/config/apps.ts`
- `src/features/apps/app-viewer.tsx`
- `src/features/apps/index.tsx`
- `src/features/dashboard/index.tsx`
- `src/routes/_app/apps/$appId.tsx`
- `tools/check.cjs`

### 삭제 (0개)

- 없음

