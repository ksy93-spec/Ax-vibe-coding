@echo off
chcp 65001 >nul
REM mi-portal 업데이트 2026.09.28.2 마무리. zip 을 킷 폴더에 푼 뒤 실행합니다.
cd /d "%~dp0.."
if not exist "package.json" (
  echo 킷 폴더가 아닙니다. zip 을 킷 폴더 안에 풀었는지 확인하세요.
  pause
  exit /b 1
)
set "CUR="
if exist "VERSION" for /f "usebackq delims=" %%v in ("VERSION") do if not defined CUR set "CUR=%%v"
if defined CUR (
  echo 이미 [%CUR%] 판입니다. 이 업데이트는 VERSION 파일이 없는 처음 판에 적용하는 것입니다.
  pause
  exit /b 1
)
copy /y "_update\VERSION" "VERSION" >nul
echo 0개 파일을 지우고 판을 2026.09.28.2 로 바꿨습니다.
echo 다음: build.bat 으로 검사와 빌드를 확인하세요.
pause
