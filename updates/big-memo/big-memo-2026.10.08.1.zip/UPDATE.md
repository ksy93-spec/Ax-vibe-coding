# big-memo 업데이트 2026.10.08.1

| 항목 | 값 |
| --- | --- |
| 적용 전 판 | 없음 (VERSION 파일이 없는 처음 판) |
| 적용 후 판 | 2026.10.08.1 |
| 커밋 | a1325bf → 6f57c06 |
| 만든 날 | 2026-10-08 |
| install.bat 다시 실행 | 필요 없음 |

## 적용 방법

1. 이 zip 을 아무 곳에나 풉니다. 바탕화면이나 다운로드 폴더도 됩니다.
2. 풀린 폴더의 `apply.bat` 을 실행합니다.
   처음 판이라 `big-memo` 폴더가 없으면 새로 만듭니다. 압축을 푼 폴더 옆(또는 같은 폴더 안)에 생깁니다.
3. 판 번호가 맞으면 파일을 복사하고, 지워진 파일을 정리하고, `VERSION` 을 올립니다.
   판이 맞지 않으면 아무것도 바꾸지 않고 멈춥니다. `updates/README.md` 목록에서 빠진 업데이트부터 순서대로 적용하세요.
4. 킷 폴더의 `index.html` 을 Chrome 이나 Edge 로 엽니다. 설치 단계는 없습니다.

적용이 끝나면 풀었던 폴더는 지워도 됩니다.

## 이번에 바뀐 내용

- 4a0bbc8 kit(big-memo): 청력이 약한 어르신용 큰 글씨 메모장

## 파일 목록

### 추가 (116개)

- `.clinerules`
- `MANIFEST.md`
- `OFFLINE.md`
- `PROMPT.md`
- `assets/css/memo.css`
- `assets/fonts/pretendard/LICENSE.txt`
- `assets/fonts/pretendard/PretendardVariable.subset.0.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.1.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.10.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.11.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.12.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.13.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.14.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.15.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.16.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.17.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.18.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.19.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.2.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.20.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.21.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.22.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.23.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.24.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.25.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.26.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.27.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.28.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.29.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.3.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.30.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.31.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.32.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.33.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.34.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.35.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.36.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.37.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.38.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.39.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.4.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.40.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.41.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.42.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.43.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.44.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.45.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.46.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.47.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.48.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.49.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.5.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.50.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.51.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.52.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.53.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.54.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.55.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.56.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.57.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.58.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.59.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.6.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.60.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.61.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.62.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.63.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.64.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.65.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.66.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.67.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.68.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.69.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.7.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.70.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.71.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.72.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.73.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.74.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.75.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.76.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.77.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.78.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.79.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.8.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.80.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.81.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.82.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.83.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.84.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.85.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.86.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.87.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.88.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.89.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.9.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.90.woff2`
- `assets/fonts/pretendard/PretendardVariable.subset.91.woff2`
- `assets/fonts/pretendard/font.css`
- `assets/icon.ico`
- `assets/icon.png`
- `index.html`
- `make-shortcut.bat`
- `make-shortcut.ps1`
- `open-app.bat`
- `open-app.ps1`
- `prompts/00-project-instructions.md`
- `prompts/10-screen-change.md`
- `prompts/20-fix-error.md`
- `prompts/README.md`
- `src/app.js`
- `src/core.js`
- `tests/core.test.js`
- `tests/index.html`
- `tests/run.cjs`
- `types/memo.d.ts`

### 수정 (0개)

- 없음

### 삭제 (0개)

- 없음

